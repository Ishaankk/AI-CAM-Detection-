// client.js - talks to the real backend (the Go API server).
// Every route and payload here is defined in the "AI Camera Backend Specification".
// The mock in mock.js implements exactly the same functions, so pages never know which one they use.

export class ApiError extends Error {
  constructor(message, status, data = {}) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

let csrf = "";

async function request(method, path, body, { form = false } = {}) {
  const headers = {};
  const opts = { method, headers, credentials: "same-origin", cache: "no-store" };
  if (body !== undefined) {
    if (form) opts.body = body;                       // FormData: browser sets the multipart header
    else { headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
  }
  if (method !== "GET") headers["X-CSRF-Token"] = csrf;
  let res;
  try {
    res = await fetch(path, opts);
  } catch {
    throw new ApiError("Can't reach the camera. Check the Wi-Fi connection.", 0);
  }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(data.error || `Request failed (${res.status})`, res.status, data);
  return data;
}

const get = (p) => request("GET", p);
const post = (p, b = {}) => request("POST", p, b);

export const realApi = {
  mock: false,

  // ---- sign-in (spec: HTTP API, SEC1-SEC4) ----
  async session() {
    const s = await get("/api/auth/session");
    csrf = s.csrf;
    return s;
  },
  async login(username, password) {
    const s = await post("/api/auth/login", { username, password });
    csrf = s.csrf;
    return s;
  },
  async logout() {
    await post("/api/auth/logout");
    csrf = "";
  },
  changePassword: (current, next) => post("/api/account/password", { current, new: next }),

  // ---- live state and controls (S7, S13) ----
  status: () => get("/api/status"),
  setArmed: (armed) => post("/api/control/arm", { armed }),
  setThreshold: (value) => post("/api/control/threshold", { value }),
  getSettings: () => get("/api/settings"),
  putSettings: (settings) => request("PUT", "/api/settings", settings),

  // ---- events (S8) ----
  events(params = {}) {
    const q = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== "" && v != null && v !== "all") q.set(k, v); });
    return get(`/api/events?${q}`);
  },
  summary: () => get("/api/events/summary"),
  review: (body) => post("/api/events/review", body),
  deleteEvents: (ids) => post("/api/events/delete", { ids }),
  thumbUrl: (ev) => `/media/thumbs/${encodeURIComponent(ev.snapshot)}`,
  photoUrl: (ev, download = false) => `/media/snapshots/${encodeURIComponent(ev.snapshot)}${download ? "?download=1" : ""}`,

  // ---- system (S11) ----
  system: () => get("/api/system"),

  // ---- people / face recognition (S12) ----
  people: () => get("/api/people"),
  /** source "photos" (1-10 files) or "camera" (no files: the worker captures the face live). */
  addPerson({ name, consent, files = [], source = "photos" }) {
    const fd = new FormData();
    fd.append("name", name);
    fd.append("consent", consent ? "true" : "false");
    fd.append("source", source);
    files.forEach((f) => fd.append("photos[]", f));
    return request("POST", "/api/people", fd, { form: true });
  },
  capturePerson: (id, count = 8) => post(`/api/people/${id}/capture`, { count }),
  deletePerson: (id) => request("DELETE", `/api/people/${id}`),
  personThumbUrl: (p) => `/media/people/${p.id}.jpg`,

  // ---- video + snapshot (S6, S10) ----
  streamUrl: () => `/api/stream?t=${Date.now()}`,       // new URL = fresh MJPEG connection
  async snapshot() {
    const res = await fetch("/api/snapshot", { credentials: "same-origin", cache: "no-store" });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new ApiError(data.error || "Couldn't take a snapshot.", res.status);
    }
    const name = /filename="?([^"]+)"?/.exec(res.headers.get("Content-Disposition") || "")?.[1] || "snapshot.jpg";
    return { blob: await res.blob(), name };
  },

  /**
   * Live updates (Server-Sent Events). `on` maps event names to handlers:
   * hello, status, health, detection, alert, tamper, people, reviewed, plus open / error.
   * Returns a function that closes the connection.
   */
  live(on) {
    const es = new EventSource("/api/live");
    es.onopen = () => on.open?.();
    es.onerror = () => on.error?.(es.readyState === EventSource.CLOSED);
    for (const name of ["hello", "status", "health", "detection", "alert", "tamper", "people", "reviewed"]) {
      es.addEventListener(name, (e) => {
        let data;
        try { data = JSON.parse(e.data); } catch { return; }
        on.message?.(name, data);
      });
    }
    return () => es.close();
  },
};
