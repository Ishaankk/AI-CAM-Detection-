// Picks the real backend or the in-browser mock, and reports expired sessions in one place.
//   npm run dev   -> real Go backend (through Vite's proxy)
//   npm run mock  -> mock.js, no backend needed
import { realApi, ApiError } from "./client.js";
import { mockApi } from "./mock.js";

const base = import.meta.env.VITE_MOCK === "true" ? mockApi : realApi;

/** Any call that comes back 401 (except the session check itself) means the session ended. */
function wrap(target) {
  const out = {};
  for (const [key, value] of Object.entries(target)) {
    if (typeof value !== "function" || key === "session" || key === "login") { out[key] = value; continue; }
    out[key] = (...args) => {
      const result = value(...args);
      if (result && typeof result.catch === "function") {
        return result.catch((err) => {
          if (err instanceof ApiError && err.status === 401) window.dispatchEvent(new Event("aicam:signed-out"));
          throw err;
        });
      }
      return result;
    };
  }
  return out;
}

export const api = wrap(base);
export { ApiError };
