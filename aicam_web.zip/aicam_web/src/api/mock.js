// mock.js - a complete fake backend that runs in the browser (`npm run mock`).
// Implements the same functions as client.js and follows the same contract, so the
// interface can be built, reviewed and user-tested with no Pi, no Go server and no broker.
// Sign in with:  admin / demo-password

import { ApiError } from "./client.js";

const MOCK_USER = "admin";
let mockPassword = "demo-password";
const W = 960, H = 540, FLOOR = 470;
const OBJECTS = [
  // kind, weight, box w, box h, typical confidence
  ["person", 0.6, 120, 300, 0.86],
  ["dog", 0.15, 170, 110, 0.74],
  ["cat", 0.1, 110, 80, 0.62],
  ["car", 0.15, 400, 185, 0.81],
];
const PEOPLE_SEED = [
  { name: "Riya", hue: 200 },
  { name: "Arjun", hue: 25 },
];

const rand = (a, b) => a + Math.random() * (b - a);
const pick = (items, weights) => {
  let r = Math.random() * weights.reduce((a, b) => a + b, 0);
  for (let i = 0; i < items.length; i++) { r -= weights[i]; if (r <= 0) return items[i]; }
  return items[items.length - 1];
};
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const iso = (d = new Date()) => {
  const off = -d.getTimezoneOffset(), sign = off >= 0 ? "+" : "-", pad = (n) => String(Math.abs(n)).padStart(2, "0");
  const local = new Date(d.getTime() + off * 60000).toISOString().slice(0, 19);
  return `${local}${sign}${pad(Math.trunc(off / 60))}:${pad(off % 60)}`;
};

// ---------------------------------------------------------------- drawing
const frame = document.createElement("canvas");
frame.width = W; frame.height = H;
const fctx = frame.getContext("2d");
let scene = null;

function drawScene() {
  const c = document.createElement("canvas");
  c.width = W; c.height = H;
  const g = c.getContext("2d");
  g.fillStyle = "#2e343c"; g.fillRect(0, 0, W, H);
  for (let y = 352; y < H; y++) {
    const v = 58 + Math.floor((y - 352) / 6);
    g.fillStyle = `rgb(${v},${v - 4},${v - 10})`; g.fillRect(0, y, W, 1);
  }
  g.fillStyle = "#463e36"; g.fillRect(105, 112, 142, 240);
  g.strokeStyle = "#5a5248"; g.lineWidth = 3; g.strokeRect(105, 112, 142, 240);
  g.fillStyle = "#5c7082"; g.fillRect(645, 90, 210, 150);
  g.strokeStyle = "#6e767e"; g.lineWidth = 5; g.strokeRect(645, 90, 210, 150);
  g.beginPath(); g.moveTo(750, 90); g.lineTo(750, 240); g.stroke();
  return c;
}

function drawVisitor(g, v, x) {
  const { kind, w, h } = v;
  const x1 = x, y2 = FLOOR, y1 = y2 - h, x2 = x + w;
  g.fillStyle = "#80868e";
  if (kind === "person") {
    g.fillStyle = `hsl(${v.hue ?? 210} 12% 55%)`;
    g.beginPath(); g.ellipse(x1 + w / 2, y1 + h * 0.1, w * 0.2, h * 0.1, 0, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.roundRect(x1 + w * 0.15, y1 + h * 0.22, w * 0.7, h * 0.4, 14); g.fill();
    g.fillRect(x1 + w * 0.25, y1 + h * 0.62, w * 0.2, h * 0.38);
    g.fillRect(x1 + w * 0.55, y1 + h * 0.62, w * 0.2, h * 0.38);
  } else if (kind === "car") {
    g.fillStyle = "#60708a";
    g.beginPath(); g.roundRect(x1, y1 + h * 0.35, w, h * 0.5, 18); g.fill();
    g.beginPath(); g.roundRect(x1 + w * 0.2, y1, w * 0.55, h * 0.45, 18); g.fill();
    g.fillStyle = "#1e1e20";
    [x1 + w * 0.2, x2 - w * 0.2].forEach((cx) => { g.beginPath(); g.arc(cx, y2 - h * 0.15, h * 0.15, 0, Math.PI * 2); g.fill(); });
  } else {
    g.beginPath(); g.ellipse(x1 + w * 0.4, y1 + h * 0.55, w * 0.4, h * 0.27, 0, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.ellipse(x2 - w * 0.17, y1 + h * 0.22, w * 0.17, h * 0.22, 0, 0, Math.PI * 2); g.fill();
    g.fillRect(x1 + w * 0.1, y2 - h * 0.3, w * 0.1, h * 0.3);
    g.fillRect(x2 - w * 0.45, y2 - h * 0.3, w * 0.1, h * 0.3);
  }
}

function drawBox(g, det) {
  const [x1, y1, x2, y2] = det.box;
  const text = `${det.labelText} ${Math.round(det.confidence * 100)}%`;
  g.strokeStyle = "#ffb020"; g.lineWidth = 2; g.strokeRect(x1, y1, x2 - x1, y2 - y1);
  g.font = "bold 15px system-ui, sans-serif";
  const tw = g.measureText(text).width + 10;
  const ty = y1 - 22 >= 0 ? y1 - 22 : y1;
  g.fillStyle = "#ffb020"; g.fillRect(x1, ty, tw, 22);
  g.fillStyle = "#121a23"; g.fillText(text, x1 + 5, ty + 16);
}

function drawClock(g, d = new Date()) {
  g.font = "13px ui-monospace, monospace";
  g.fillStyle = "rgba(230,235,240,.85)";
  g.fillText(d.toLocaleString([], { hour12: false }), 16, 24);
}

function toUrl(canvas, w, h, q) {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  c.getContext("2d").drawImage(canvas, 0, 0, w, h);
  return c.toDataURL("image/jpeg", q);
}

function avatarFor(name, hue) {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d");
  g.fillStyle = `hsl(${hue} 30% 86%)`; g.fillRect(0, 0, 128, 128);
  g.fillStyle = `hsl(${hue} 18% 45%)`;
  g.beginPath(); g.arc(64, 52, 26, 0, Math.PI * 2); g.fill();
  g.beginPath(); g.ellipse(64, 128, 46, 40, 0, 0, Math.PI * 2); g.fill();
  return c.toDataURL("image/jpeg", 0.85);
}

// ---------------------------------------------------------------- world state
const world = {
  armed: true, threshold: 0.5, recognition: true, alertKnown: false,
  temp: 51.5, fps: 29.6, startedAt: Date.now(), bootOffset: 3 * 86400 + 4000,
  events: [], nextId: 1, people: [], nextPersonId: 1,
  history: [], lastStatusAt: 0, lastFrameAt: 0,
  visitor: null, nextVisit: Date.now() + 2500, nextTamper: Date.now() + rand(60000, 120000),
  lastByKey: {}, cameraOffline: false, dropUntil: 0, viewers: new Set(),
  started: false, loginFails: [],
};

function makeIdentity() {
  if (!world.recognition) return null;
  const ready = world.people.filter((p) => p.state === "ready");
  const kind = pick(["known", "unknown", "no_face"], [ready.length ? 0.5 : 0, 0.3, 0.2]);
  if (kind === "known") {
    const p = ready[Math.floor(Math.random() * ready.length)];
    return { status: "known", person_id: p.id, name: p.name, score: +rand(0.45, 0.72).toFixed(2), hue: p.hue };
  }
  if (kind === "unknown") return { status: "unknown", person_id: null, name: null, score: +rand(0.08, 0.3).toFixed(2) };
  return { status: "no_face", person_id: null, name: null, score: null };
}

function displayLabel(object, identity) {
  if (object !== "person" || !identity) return object.charAt(0).toUpperCase() + object.slice(1);
  if (identity.status === "known") return identity.name;
  if (identity.status === "unknown") return "Unknown";
  return "Person";
}

function saveEvent({ object, confidence, box, identity, when = new Date(), picture }) {
  const id = world.nextId++;
  const uid = `${iso(when).replace(/[-:]/g, "").slice(0, 15)}-${Math.random().toString(16).slice(2, 6)}`;
  const { hue, ...publicIdentity } = identity || {};
  const ev = {
    id, uid, time: iso(when), object, confidence: +confidence.toFixed(3), box: box.map(Math.round),
    snapshot: `${uid}.jpg`, stage: object === "person" && identity ? 2 : 1,
    identity: identity ? publicIdentity : null, reviewed: false,
    _photo: toUrl(picture, W, H, 0.8), _thumb: toUrl(picture, 320, 180, 0.7),
  };
  world.events.unshift(ev);
  if (world.events.length > 500) world.events.length = 500;      // retention, like the real server
  return ev;
}

function seed() {
  scene = drawScene();
  PEOPLE_SEED.forEach(({ name, hue }) => {
    world.people.push({ id: world.nextPersonId++, name, hue, samples: 8, state: "ready", error: null,
      added: iso(new Date(Date.now() - 9 * 86400000)), consent_at: iso(new Date(Date.now() - 9 * 86400000)), _thumb: avatarFor(name, hue) });
  });
  const pic = document.createElement("canvas");
  pic.width = W; pic.height = H;
  const g = pic.getContext("2d");
  const times = Array.from({ length: 38 }, () => Date.now() - rand(5, 24 * 60) * 60000).sort((a, b) => a - b);
  for (const t of times) {
    const [kind, , w, h, conf] = pick(OBJECTS, OBJECTS.map((o) => o[1]));
    const identity = kind === "person" ? makeIdentity() : null;
    const x = rand(30, W - w - 30);
    g.drawImage(scene, 0, 0);
    drawVisitor(g, { kind, w, h, hue: identity?.hue }, x);
    const confidence = Math.min(0.97, Math.max(0.35, conf + rand(-0.12, 0.1)));
    const box = [x, FLOOR - h, x + w, FLOOR];
    drawBox(g, { box, confidence, labelText: displayLabel(kind, identity) });
    drawClock(g, new Date(t));
    const ev = saveEvent({ object: kind, confidence, box, identity, when: new Date(t), picture: pic });
    ev.reviewed = t < Date.now() - 6 * 3600000;
  }
  // 30 minutes of past status history, so the System charts aren't empty on first open
  for (let t = Date.now() - 30 * 60000; t < Date.now(); t += 2000) {
    world.temp = nextTemp();
    world.fps = Math.min(30, Math.max(28.6, world.fps + rand(-0.15, 0.15)));
    world.history.push({ t: t / 1000, temp_c: world.temp, fps: +world.fps.toFixed(1), free_gb: 21.4, load_1m: +rand(0.7, 1.3).toFixed(2) });
  }
}

function nextTemp() {
  world.temp = Math.min(63, Math.max(46, world.temp + rand(-0.3, 0.35) + (51.5 - world.temp) * 0.03));
  return +world.temp.toFixed(1);
}

// ---------------------------------------------------------------- live updates
const subscribers = new Set();
const dropped = () => Date.now() < world.dropUntil;
function emit(name, data) {
  if (dropped()) return;
  subscribers.forEach((s) => s.message?.(name, data));
}

function statusPayload() {
  return {
    online: !world.cameraOffline, armed: world.armed, threshold: world.threshold, recognition: world.recognition,
    temp_c: world.temp, fps: world.cameraOffline ? 0 : +world.fps.toFixed(1), free_gb: 21.4, low_space: false,
    uptime_s: Math.round((Date.now() - world.startedAt) / 1000 + world.bootOffset), load_1m: +rand(0.7, 1.4).toFixed(2), time: iso(),
  };
}
function health() {
  const now = Date.now();
  return {
    frame_age: world.lastFrameAt ? +((now - world.lastFrameAt) / 1000).toFixed(1) : null,
    status_age: world.lastStatusAt ? +((now - world.lastStatusAt) / 1000).toFixed(1) : null,
    broker: "connected", viewers: Math.max(1, world.viewers.size),
  };
}
function publishStatus() {
  if (world.cameraOffline) return;                 // an offline camera sends nothing (its last will was already sent)
  nextTemp();
  world.lastStatusAt = Date.now();
  const s = statusPayload();
  world.history.push({ t: Date.now() / 1000, temp_c: s.temp_c, fps: s.fps, free_gb: s.free_gb, load_1m: s.load_1m });
  if (world.history.length > 1000) world.history.splice(0, world.history.length - 1000);
  emit("status", s);
}

function tick() {
  const now = Date.now();
  if (world.cameraOffline) return;
  world.lastFrameAt = now;
  world.fps = Math.min(30, Math.max(28.6, world.fps + rand(-0.02, 0.02) + (29.6 - world.fps) * 0.01));

  fctx.drawImage(scene, 0, 0);
  drawClock(fctx);
  if (!world.visitor && now >= world.nextVisit) {
    const [kind, , w, h, conf] = pick(OBJECTS, OBJECTS.map((o) => o[1]));
    const identity = kind === "person" ? makeIdentity() : null;
    world.visitor = { kind, w, h, conf: conf + rand(-0.1, 0.08), start: now, dur: rand(6000, 10000), rev: Math.random() < 0.5, identity, hue: identity?.hue };
  }
  const v = world.visitor;
  if (v) {
    let p = (now - v.start) / v.dur;
    if (p >= 1) {
      world.visitor = null;
      world.nextVisit = now + rand(6000, 16000);
    } else {
      p = v.rev ? 1 - p : p;
      const x = -v.w + p * (W + v.w);
      drawVisitor(fctx, v, x);
      const confidence = Math.max(0.05, Math.min(0.99, v.conf + rand(-0.04, 0.04)));
      const box = [Math.max(0, x), FLOOR - v.h, Math.min(W, x + v.w), FLOOR];
      if (confidence >= world.threshold && box[2] - box[0] > v.w * 0.6) {
        const det = { box, confidence, labelText: displayLabel(v.kind, v.identity) };
        drawBox(fctx, det);
        maybeReport(v, det, now);
      }
    }
  }
  if (world.armed && now >= world.nextTamper) {
    emit("tamper", { time: iso() });
    world.nextTamper = now + rand(90000, 180000);
  }
}

function maybeReport(v, det, now) {
  // one event per visit (the worker reuses its result for the whole event), plus the 5 s cooldown
  const key = v.identity?.status === "known" ? `id-${v.identity.person_id}` : v.kind;
  if (!world.armed || v.reported || now - (world.lastByKey[key] || 0) < 5000) return;
  v.reported = true;
  world.lastByKey[key] = now;
  const ev = saveEvent({ object: v.kind, confidence: det.confidence, box: det.box, identity: v.identity, picture: frame });
  const known = ev.identity?.status === "known";
  emit("detection", publicEvent(ev));
  if (!known || world.alertKnown) emit("alert", { type: "detection", id: ev.id, time: ev.time, object: ev.object, identity: ev.identity });
}

function start() {
  if (world.started) return;
  world.started = true;
  seed();
  setInterval(tick, 1000 / 12);
  setInterval(publishStatus, 2000);
  setInterval(() => emit("health", health()), 1000);
  publishStatus();
}

// strip private fields (_photo/_thumb) but keep them reachable for the URL helpers
const publicEvent = (ev) => ({ ...ev });

// ---------------------------------------------------------------- the API
function needLogin() {
  let ok = false;
  try { ok = sessionStorage.getItem("aicam.mock.session") === "1"; } catch { /* ignore */ }
  if (!ok) throw new ApiError("Please sign in.", 401);
}

function filterEvents({ object = "all", who = "all", reviewed = "all", from = "", to = "" } = {}) {
  return world.events.filter((e) => {
    if (object !== "all" && e.object !== object) return false;
    if (who !== "all") {
      const st = e.identity?.status;
      if (who === "known" || who === "unknown" || who === "no_face") { if (st !== who) return false; }
      else if (String(e.identity?.person_id) !== String(who)) return false;
    }
    if (reviewed === "0" && e.reviewed) return false;
    if (reviewed === "1" && !e.reviewed) return false;
    const d = e.time.slice(0, 10);
    if (from && d < from) return false;
    if (to && d > to) return false;
    return true;
  });
}

export const mockApi = {
  mock: true,

  async session() {
    start();
    await wait(80);
    needLogin();
    return { user: MOCK_USER, csrf: "mock", version: "3.0 (mock)" };
  },
  async login(username, password) {
    start();
    await wait(350);
    const now = Date.now();
    world.loginFails = world.loginFails.filter((t) => t > now - 300000);
    if (world.loginFails.length >= 5) throw new ApiError("Too many attempts. Try again in 5 min.", 429);
    if (username.trim().toLowerCase() !== MOCK_USER || password !== mockPassword) {
      world.loginFails.push(now);
      if (world.loginFails.length >= 5) throw new ApiError("Too many attempts. Try again in 5 min.", 429);
      throw new ApiError("That username or password isn't right.", 401);
    }
    world.loginFails = [];
    try { sessionStorage.setItem("aicam.mock.session", "1"); } catch { /* ignore */ }
    return { user: MOCK_USER, csrf: "mock", version: "3.0 (mock)" };
  },
  async logout() {
    try { sessionStorage.removeItem("aicam.mock.session"); } catch { /* ignore */ }
  },
  async changePassword(current, next) {
    await wait(300);
    if (current !== mockPassword) throw new ApiError("Your current password isn't right.", 400);
    if ((next || "").length < 12) throw new ApiError("Use at least 12 characters.", 400);
    mockPassword = next;
    return null;
  },

  async status() { needLogin(); return { status: statusPayload(), latest: world.events[0] ? publicEvent(world.events[0]) : null, health: health() }; },
  async setArmed(armed) {
    needLogin();
    setTimeout(() => { world.armed = !!armed; publishStatus(); }, 300);
    return { pending: true };
  },
  async setThreshold(value) {
    needLogin();
    setTimeout(() => { world.threshold = Math.round(value * 100) / 100; publishStatus(); }, 300);
    return { pending: true };
  },
  async getSettings() { needLogin(); return { recognition: world.recognition, alert_known_people: world.alertKnown }; },
  async putSettings(s) {
    needLogin();
    await wait(200);
    if (typeof s.recognition === "boolean") world.recognition = s.recognition;
    if (typeof s.alert_known_people === "boolean") world.alertKnown = s.alert_known_people;
    publishStatus();
    return { recognition: world.recognition, alert_known_people: world.alertKnown };
  },

  async events(params = {}) {
    needLogin();
    await wait(120);
    const limit = Math.min(100, Number(params.limit) || 48);
    const all = filterEvents(params);
    const before = params.before ? Number(params.before) : null;
    const page = (before ? all.filter((e) => e.id < before) : all).slice(0, limit + 1);
    const items = page.slice(0, limit).map(publicEvent);
    return { items, next: page.length > limit ? items[items.length - 1].id : null, total: all.length };
  },
  async summary() {
    needLogin();
    const objects = {};
    world.events.forEach((e) => { objects[e.object] = (objects[e.object] || 0) + 1; });
    const cut = Date.now() / 1000 - 86400;
    return {
      objects,
      unreviewed: world.events.filter((e) => !e.reviewed).length,
      recent_ts: world.events.map((e) => new Date(e.time).getTime() / 1000).filter((t) => t >= cut),
    };
  },
  async review({ ids, all, reviewed = true }) {
    needLogin();
    let n = 0;
    world.events.forEach((e) => {
      if ((all || ids?.includes(e.id)) && e.reviewed !== reviewed) { e.reviewed = reviewed; n++; }
    });
    emit("reviewed", { changed: n });
    return { changed: n };
  },
  async deleteEvents(ids) {
    needLogin();
    const before = world.events.length;
    world.events = world.events.filter((e) => !ids.includes(e.id));
    const n = before - world.events.length;
    emit("reviewed", { changed: n });
    return { deleted: n };
  },
  thumbUrl: (ev) => world.events.find((e) => e.id === ev.id)?._thumb || ev._thumb || "",
  photoUrl: (ev) => world.events.find((e) => e.id === ev.id)?._photo || ev._photo || "",

  async system() {
    needLogin();
    await wait(100);
    const cut = Date.now() / 1000 - 1800;
    return {
      status: statusPayload(), health: health(), history: world.history.filter((h) => h.t >= cut),
      server_uptime_s: Math.round((Date.now() - world.startedAt) / 1000 + 3 * 86400),
      snapshots: world.events.length, version: "3.0 (mock)", https: false,
      retention: { keep: 500, days: 14, min_free_gb: 1 },
    };
  },

  async people() {
    needLogin();
    await wait(100);
    return world.people.map(({ _thumb, hue, ...p }) => p);
  },
  async addPerson({ name, consent, files = [], source = "photos" }) {
    needLogin();
    await wait(400);
    const clean = (name || "").trim();
    if (!clean || clean.length > 40) throw new ApiError("Give a name of 1 to 40 characters.", 400);
    if (!consent) throw new ApiError("Confirm that this person agreed to be recognised.", 400);
    if (source === "photos" && (!files.length || files.length > 10)) throw new ApiError("Add between 1 and 10 photos.", 400);
    if (files.some((f) => !/^image\/(jpeg|png)$/.test(f.type))) throw new ApiError("Photos must be JPEG or PNG.", 400);
    if (files.some((f) => f.size > 5 * 1024 * 1024)) throw new ApiError("Each photo must be 5 MB or smaller.", 400);
    const hue = Math.floor(rand(0, 360));
    const person = { id: world.nextPersonId++, name: clean, hue, samples: 0, state: "enrolling", error: null, added: iso(), consent_at: iso(), _thumb: avatarFor(clean, hue) };
    world.people.push(person);
    if (source === "camera") {
      setTimeout(() => {
        person.state = "ready"; person.samples = 7;
        emit("people", { id: person.id, state: person.state, samples: person.samples, error: null });
      }, 3500);
      return { id: person.id, state: "enrolling" };
    }
    try {
      const bmp = await createImageBitmap(files[0]);
      const c = document.createElement("canvas");
      c.width = c.height = 128;
      const s = Math.min(bmp.width, bmp.height);
      c.getContext("2d").drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, 128, 128);
      person._thumb = c.toDataURL("image/jpeg", 0.85);
    } catch { /* keep the drawn avatar */ }
    setTimeout(() => {
      const usable = files.length - (files.length > 3 ? Math.round(rand(0, 1)) : 0);
      if (usable < 3) { person.state = "failed"; person.error = "Need at least 3 photos with one clear face."; }
      else { person.state = "ready"; person.samples = usable; }
      emit("people", { id: person.id, state: person.state, samples: person.samples, error: person.error });
    }, 2500);
    return { id: person.id, state: "enrolling" };
  },
  async capturePerson(id, count = 8) {
    needLogin();
    const p = world.people.find((x) => x.id === id);
    if (!p) throw new ApiError("That person no longer exists.", 404);
    p.state = "enrolling"; p.error = null;
    setTimeout(() => {
      p.state = "ready"; p.samples = Math.max(p.samples, count - 1);
      emit("people", { id: p.id, state: p.state, samples: p.samples, error: null });
    }, 3500);
    return { id, state: "enrolling" };
  },
  async deletePerson(id) {
    needLogin();
    await wait(200);
    world.people = world.people.filter((p) => p.id !== id);
    world.events.forEach((e) => {
      if (e.identity?.person_id === id) e.identity = { ...e.identity, person_id: null, name: null };
    });
    return null;
  },
  personThumbUrl: (p) => world.people.find((x) => x.id === p.id)?._thumb || "",

  streamUrl: () => "",
  /** Mock only: copy the fake camera picture into a canvas on the Live page. Returns a stop function. */
  attachVideo(canvas) {
    const g = canvas.getContext("2d");
    canvas.width = W; canvas.height = H;
    world.viewers.add(canvas);
    const t = setInterval(() => { if (!world.cameraOffline && !dropped()) g.drawImage(frame, 0, 0); }, 1000 / 12);
    return () => { clearInterval(t); world.viewers.delete(canvas); };
  },
  async snapshot() {
    needLogin();
    if (world.cameraOffline) throw new ApiError("No picture from the camera yet.", 404);
    const blob = await new Promise((r) => frame.toBlob(r, "image/jpeg", 0.9));
    const d = new Date(), p = (n) => String(n).padStart(2, "0");
    const name = `aicam_${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}.jpg`;
    return { blob, name };
  },

  live(on) {
    start();
    const sub = { ...on };
    subscribers.add(sub);
    // like a real network: a dropped link only reconnects once it's back
    const delay = Math.max(150, world.dropUntil - Date.now() + 150);
    const opened = setTimeout(() => {
      on.open?.();
      on.message?.("hello", { status: statusPayload(), latest: world.events[0] ? publicEvent(world.events[0]) : null, health: health() });
    }, delay);
    return () => { clearTimeout(opened); subscribers.delete(sub); };
  },

  // ---- test controls for reviewers (shown in the "Mock data" menu) ----
  simulate: {
    detection() { world.nextVisit = Date.now(); world.lastByKey = {}; },
    tamper() { if (world.armed) emit("tamper", { time: iso() }); },
    cameraOffline(off) {
      world.cameraOffline = off;
      if (off) emit("status", { online: false, reason: "connection lost" });
      else publishStatus();
    },
    dropConnection(seconds = 12) { world.dropUntil = Date.now() + seconds * 1000; },
    isOffline: () => world.cameraOffline,
  },
};
