import { useEffect, useState } from "react";
import { useLive } from "../state/LiveContext.jsx";

export function Switch({ checked, onChange, disabled, labelledBy, label }) {
  return (
    <button type="button" className="switch" role="switch" aria-checked={!!checked} aria-labelledby={labelledBy}
      aria-label={labelledBy ? undefined : label} disabled={disabled} onClick={() => onChange(!checked)}>
      <span className="switch-knob" />
    </button>
  );
}

/** F6: alerts on/off. Shows "Turning on…" until the camera's status confirms it. */
export function useArmState() {
  const { status, pending, liveness, setArmed, controlMsg } = useLive();
  const known = status && "armed" in status;
  const p = pending.arm;
  const shown = p ? p.want : !!status?.armed;
  const word = !known ? "Checking…" : p ? (p.want ? "Turning on…" : "Turning off…") : status.armed ? "On" : "Off";
  const sub = !known ? "" : p ? "Waiting for the camera to confirm"
    : status.armed ? "Detections are saved and alert you" : "Nothing is saved or alerted";
  return {
    checked: shown, word, sub, isOn: known && !p && status.armed,
    disabled: !known || !!p || !liveness.cameraOnline,
    toggle: () => known && setArmed(!status.armed),
    msg: controlMsg,
  };
}

const KEYS = new Set(["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Home", "End", "PageUp", "PageDown"]);

/** F7: higher sensitivity = lower confidence threshold. Keeps in step with the camera's real value. */
export function useSensitivity() {
  const { status, pending, setThreshold } = useLive();
  const [value, setValue] = useState(50);
  const [dragging, setDragging] = useState(false);
  useEffect(() => {
    if (!dragging && !pending.threshold && typeof status?.threshold === "number") {
      setValue(Math.round((1 - status.threshold) * 20) * 5);
    }
  }, [status?.threshold, pending.threshold, dragging]);
  return {
    value,
    level: value >= 70 ? "High" : value >= 40 ? "Medium" : "Low",
    help: `Alerts when the camera is at least ${100 - value}% sure`,
    markPct: 100 - value,
    inputProps: {
      type: "range", min: 5, max: 95, step: 5, value, className: "range",
      onChange: (e) => { setDragging(true); setValue(Number(e.target.value)); },
      // send to the camera when the user lets go (mouse, touch or keyboard), not on every pixel
      onPointerUp: (e) => { setDragging(false); setThreshold((100 - Number(e.currentTarget.value)) / 100); },
      onKeyUp: (e) => {
        setDragging(false);
        if (KEYS.has(e.key)) setThreshold((100 - Number(e.currentTarget.value)) / 100);
      },
    },
  };
}

export function IdentityBadge({ ev }) {
  const id = ev?.identity;
  if (!id || ev.object !== "person") return null;
  const map = {
    known: ["id-known", "Recognised"],
    unknown: ["id-unknown", "Not recognised"],
    no_face: ["id-noface", "Face not visible"],
  };
  const [cls, text] = map[id.status] || map.no_face;
  return <span className={`id-badge ${cls}`}>{text}</span>;
}

export function EmptyState({ icon: Icon, title, children }) {
  return (
    <div className="card empty-state">
      {Icon && <Icon className="ico ico-xl" aria-hidden="true" />}
      <h2>{title}</h2>
      {children && <p className="muted">{children}</p>}
    </div>
  );
}
