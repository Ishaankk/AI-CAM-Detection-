import { useState } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import {
  Activity, Bell, CircleAlert, Gauge, HardDrive, Images, LogOut, Settings, ShieldCheck,
  Thermometer, TriangleAlert, User, Users, Video, Wifi, X,
} from "lucide-react";
import { api } from "../api/index.js";
import { useAuth } from "../state/AuthContext.jsx";
import { useLive } from "../state/LiveContext.jsx";
import logo from "../logo.svg";

/** Pages in the menu. Adding a page = one line here + one route in App.jsx. */
export const NAV = [
  { to: "/", label: "Live", icon: Video, end: true },
  { to: "/events", label: "Events", icon: Images, badge: "unreviewed" },
  { to: "/people", label: "People", icon: Users },
  { to: "/system", label: "System", icon: Activity },
  { to: "/settings", label: "Settings", icon: Settings },
];

function Pill({ state, icon: Icon, children, reading = false, hot = false, title }) {
  return (
    <span className={`pill${reading ? " pill-reading" : ""}${hot ? " is-hot" : ""}`} data-state={state} title={title}>
      <Icon className="ico" aria-hidden="true" />
      <span className={reading ? "mono" : undefined}>{children}</span>
    </span>
  );
}

function StatusPills() {
  const { status: s, liveness: L } = useLive();
  const online = L.connecting ? ["unknown", "Connecting"] : L.cameraOnline ? ["ok", "Camera online"] : ["bad", "Camera offline"];
  let armed = ["unknown", "Checking"];
  if (s && "armed" in s) {
    const word = s.armed ? "Alerts on" : "Alerts off";
    armed = [!L.cameraOnline ? "unknown" : s.armed ? "ok" : "off", L.cameraOnline ? word : `${word} (last known)`];
  }
  const t = s?.temp_c;
  return (
    <div className="pills" aria-label="System status">
      <Pill state={online[0]} icon={Wifi}>{online[1]}</Pill>
      <Pill state={armed[0]} icon={ShieldCheck}>{armed[1]}</Pill>
      <Pill icon={Thermometer} reading hot={t != null && t >= 75} title="Pi temperature">
        {t == null || !L.cameraOnline ? "–" : `${Math.round(t)} °C`}
      </Pill>
      <Pill icon={Gauge} reading title="Camera frame rate">
        {s?.fps == null || !L.cameraOnline ? "– fps" : `${Math.round(s.fps)} fps`}
      </Pill>
      {s?.low_space && <Pill state="warn" icon={HardDrive}>Storage almost full</Pill>}
    </div>
  );
}

function ConnCard() {
  const { liveness: L, health } = useLive();
  let st = "unknown", title = "Connecting…", sub = "Waiting for the camera";
  if (!L.connecting && !L.linkOk) { st = "bad"; title = "Connection lost"; sub = `Reconnecting · ${Math.round(L.linkAge / 1000)} s`; }
  else if (!L.connecting && !L.cameraOnline) { st = "bad"; title = "Camera offline"; sub = "The page is fine; the camera isn't reporting"; }
  else if (L.cameraOnline) {
    st = "ok"; title = "All systems live";
    const v = health?.viewers;
    sub = v ? `${v} viewer${v === 1 ? "" : "s"} open` : "Receiving updates";
  }
  return (
    <div className="conn" data-state={st} role="status">
      <span className="conn-dot" aria-hidden="true" />
      <span className="conn-text"><b>{title}</b><small>{sub}</small></span>
    </div>
  );
}

function Toasts() {
  const { toasts, dismiss } = useLive();
  const iconFor = { tamper: TriangleAlert, detect: CircleAlert, info: Bell };
  return (
    <div className="toasts" aria-live="assertive">
      {toasts.map((t) => {
        const Icon = iconFor[t.kind] || Bell;
        return (
          <div key={t.id} className={`toast toast-${t.kind}`} role={t.kind === "info" ? "status" : "alert"}>
            <span className="toast-icon"><Icon className="ico" aria-hidden="true" /></span>
            <div>
              <b>{t.title}</b>
              {t.sub && <small>{t.sub}</small>}
              {t.href && <div><Link to={t.href} onClick={() => dismiss(t.id)}>{t.linkText || "View"}</Link></div>}
            </div>
            <button type="button" className="btn btn-ghost btn-icon" aria-label="Dismiss" onClick={() => dismiss(t.id)}>
              <X className="ico" aria-hidden="true" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

/** Mock mode only: buttons a reviewer can use to see every state without hardware. */
function MockControls() {
  const [open, setOpen] = useState(false);
  const [, force] = useState(0);
  if (!api.mock) return null;
  const sim = api.simulate;
  const offline = sim.isOffline();
  return (
    <div className="mock-flag" role="region" aria-label="Mock data controls">
      Mock data
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open}>{open ? "Hide" : "Simulate"}</button>
      {open && (
        <>
          <button type="button" onClick={sim.detection}>Detection</button>
          <button type="button" onClick={sim.tamper}>Tamper</button>
          <button type="button" onClick={() => { sim.cameraOffline(!offline); force((n) => n + 1); }}>
            {offline ? "Camera back" : "Camera offline"}
          </button>
          <button type="button" onClick={() => sim.dropConnection(12)}>Drop Wi-Fi 12 s</button>
        </>
      )}
    </div>
  );
}

export function Layout() {
  const { pathname } = useLocation();
  const title = NAV.find((n) => (n.end ? pathname === n.to : pathname.startsWith(n.to)))?.label || "Page not found";
  const { user, logout } = useAuth();
  const { summary } = useLive();
  const unreviewed = summary?.unreviewed || 0;
  return (
    <>
      <a className="skip" href="#main">Skip to content</a>
      <div className="shell">
        <aside className="sidebar" aria-label="Main">
          <Link className="brand" to="/">
            <img src={logo} alt="" width="32" height="32" />
            <span className="brand-text"><b>AI Camera</b><small>Monitoring</small></span>
          </Link>
          <nav className="nav">
            {NAV.map(({ to, label, icon: Icon, end, badge }) => (
              <NavLink key={to} to={to} end={end} className={({ isActive }) => `nav-link${isActive ? " is-active" : ""}`}>
                <Icon className="ico" aria-hidden="true" />
                <span>{label}</span>
                {badge === "unreviewed" && unreviewed > 0 && (
                  <span className="nav-badge" aria-label={`${unreviewed} to review`}>{unreviewed > 99 ? "99+" : unreviewed}</span>
                )}
              </NavLink>
            ))}
          </nav>
          <div className="sidebar-foot">
            <ConnCard />
            <div className="signout">
              <span className="who"><User className="ico" aria-hidden="true" />{user}</span>
              <button type="button" className="btn btn-ghost btn-sm" onClick={logout}>
                <LogOut className="ico" aria-hidden="true" /><span>Sign out</span>
              </button>
            </div>
          </div>
        </aside>

        <div className="main-col">
          <header className="topbar">
            <h1 className="page-title">{title}</h1>
            {api.mock && <span className="tag tag-demo" title="Fake camera data for testing">Demo data</span>}
            <div className="spacer" />
            <StatusPills />
          </header>
          <main id="main" className="content">
            <Outlet />
          </main>
        </div>
      </div>
      <Toasts />
      <MockControls />
    </>
  );
}
