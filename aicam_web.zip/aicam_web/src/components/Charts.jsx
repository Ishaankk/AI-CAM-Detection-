// Small hand-drawn SVG charts: no chart library needed.
import { useWidth } from "../lib/hooks.js";

const hhmm = (ts) => new Date(ts * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });

/** Detections per hour for the last 24 h, bucketed by the viewer's own clock. */
export function bucketByHour(tsList, now = Date.now()) {
  const h = new Date(now);
  h.setMinutes(0, 0, 0);
  const start = h.getTime() / 1000 - 23 * 3600;
  const counts = new Array(24).fill(0);
  (tsList || []).forEach((ts) => {
    const i = Math.floor((ts - start) / 3600);
    if (i >= 0 && i < 24) counts[i] += 1;
  });
  return { counts, start };
}

export function ActivityChart({ counts, start }) {
  const [ref, width] = useWidth();
  const W = Math.max(320, width), H = 112, bottom = 20, top = 6, gap = 4;
  const max = Math.max(1, ...counts);
  const bw = (W - gap * 23) / 24;
  return (
    <div className="activity-chart" ref={ref} role="img" aria-label="Detections per hour, last 24 hours">
      {width > 0 && (
        <svg viewBox={`0 0 ${W} ${H}`}>
          {counts.map((n, i) => {
            const hgt = n ? Math.max(3, ((H - top - bottom) * n) / max) : 2;
            const t = start + i * 3600;
            return (
              <rect key={i} x={i * (bw + gap)} y={H - bottom - hgt} width={bw} height={hgt} rx="3" className={`bar${i === 23 ? " is-now" : ""}`}>
                <title>{`${hhmm(t)}: ${n} detection${n === 1 ? "" : "s"}`}</title>
              </rect>
            );
          })}
          {[0, 6, 12, 18].map((i) => (
            <text key={i} x={i * (bw + gap)} y={H - 4} className="axis-text">{hhmm(start + i * 3600)}</text>
          ))}
          <text x={W} y={H - 4} textAnchor="end" className="axis-text">now</text>
        </svg>
      )}
    </div>
  );
}

/** One measure over the last `windowS` seconds, with an optional limit line. */
export function LineChart({ rows, field, unit, label, windowS = 1800, limit = null, limitText = "" }) {
  const [ref, width] = useWidth();
  const pts = (rows || []).filter((r) => r[field] != null);
  if (pts.length < 2) {
    return <div className="line-chart" ref={ref}><div className="chart-empty">Collecting data…</div></div>;
  }
  const W = Math.max(300, width), H = 180, L = 40, R = 12, T = 10, B = 22;
  const now = Date.now() / 1000;
  const t0 = Math.min(now - 60, Math.max(now - windowS, pts[0].t));
  const span = now - t0;
  const vals = pts.map((p) => p[field]);
  const vmax = Math.max(...vals);
  const useLimit = limit != null && vmax > limit - 15;
  let lo = Math.min(...vals, useLimit ? limit : Infinity);
  let hi = Math.max(...vals, useLimit ? limit : -Infinity);
  const pad = (hi - lo) * 0.15 + 1;
  lo = Math.max(0, Math.floor(lo - pad));
  hi = Math.ceil(hi + pad);
  const X = (t) => L + ((t - t0) / span) * (W - L - R);
  const Y = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const line = pts.map((p, i) => `${i ? "L" : "M"}${X(p.t).toFixed(1)} ${Y(p[field]).toFixed(1)}`).join(" ");
  const last = pts[pts.length - 1];
  const digits = hi - lo < 6 ? 1 : 0;
  const mins = Math.max(1, Math.round(span / 60));
  return (
    <div className="line-chart" ref={ref} role="img" aria-label={label}>
      {width > 0 && (
        <svg viewBox={`0 0 ${W} ${H}`}>
          {[0, 1, 2, 3].map((i) => {
            const v = lo + ((hi - lo) * i) / 3;
            return (
              <g key={i}>
                <line x1={L} x2={W - R} y1={Y(v)} y2={Y(v)} className="grid-line" />
                <text x={L - 8} y={Y(v) + 4} textAnchor="end" className="axis-text">{v.toFixed(digits)}</text>
              </g>
            );
          })}
          <text x={L} y={H - 4} className="axis-text">{span >= windowS - 5 ? "30 min ago" : `${mins} min ago`}</text>
          <text x={W - R} y={H - 4} textAnchor="end" className="axis-text">now</text>
          {useLimit && (
            <g>
              <line x1={L} x2={W - R} y1={Y(limit)} y2={Y(limit)} className="limit-line" />
              <text x={W - R} y={Y(limit) - 5} textAnchor="end" className="limit-text">{limitText || `${limit}${unit}`}</text>
            </g>
          )}
          <path d={`${line} L${X(last.t).toFixed(1)} ${Y(lo)} L${X(pts[0].t).toFixed(1)} ${Y(lo)} Z`} className="series-area" />
          <path d={line} className="series" />
          <circle cx={X(last.t)} cy={Y(last[field])} r="3.5" className="series-end" />
        </svg>
      )}
    </div>
  );
}
