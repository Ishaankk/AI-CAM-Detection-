import { useEffect, useRef } from "react";
import { Check, ChevronLeft, ChevronRight, Download, Trash2, X } from "lucide-react";
import { api } from "../api/index.js";
import { clock, day, pct, who } from "../lib/format.js";
import { IdentityBadge } from "./Controls.jsx";

/** Full-size photo of one event, with review / download / delete. Arrow keys move, R marks reviewed. */
export function EventViewer({ ev, hasPrev, hasNext, onPrev, onNext, onClose, onToggleReviewed, onDelete }) {
  const ref = useRef(null);

  useEffect(() => {
    const d = ref.current;
    if (ev && d && !d.open) d.showModal();
    if (!ev && d?.open) d.close();
  }, [ev]);

  if (!ev) return <dialog ref={ref} className="viewer" />;
  const onKey = (e) => {
    if (e.key === "ArrowLeft" && hasPrev) { e.preventDefault(); onPrev(); }
    else if (e.key === "ArrowRight" && hasNext) { e.preventDefault(); onNext(); }
    else if (e.key.toLowerCase() === "r" && !e.ctrlKey && !e.metaKey) { e.preventDefault(); onToggleReviewed(); }
  };
  const id = ev.identity;
  return (
    <dialog ref={ref} className="viewer" aria-labelledby="viewer-title" onClose={onClose} onKeyDown={onKey}
      onClick={(e) => { if (e.target === ref.current) ref.current.close(); }}>
      <div className="viewer-body">
        <div className="viewer-media">
          <img src={api.photoUrl(ev)} alt={`${who(ev)} at ${clock(ev.time)}`} />
          <button type="button" className="viewer-nav prev" aria-label="Previous event" disabled={!hasPrev} onClick={onPrev}>
            <ChevronLeft className="ico" aria-hidden="true" />
          </button>
          <button type="button" className="viewer-nav next" aria-label="Next event" disabled={!hasNext} onClick={onNext}>
            <ChevronRight className="ico" aria-hidden="true" />
          </button>
        </div>
        <aside className="viewer-info">
          <div className="viewer-top">
            <div>
              <h2 id="viewer-title">{who(ev)}</h2>
              <div style={{ marginTop: ".5rem" }}><IdentityBadge ev={ev} /></div>
            </div>
            <button type="button" className="btn btn-ghost btn-icon" aria-label="Close" onClick={() => ref.current.close()}>
              <X className="ico" aria-hidden="true" />
            </button>
          </div>
          <dl className="facts">
            <dt>Object</dt><dd>{ev.object.charAt(0).toUpperCase() + ev.object.slice(1)}, {pct(ev.confidence)} sure</dd>
            {id?.status === "known" && id.score != null && <><dt>Face match</dt><dd>{pct(id.score)}</dd></>}
            <dt>Day</dt><dd>{day(ev.time)}</dd>
            <dt>Time</dt><dd>{clock(ev.time)}</dd>
            <dt>Event</dt><dd>#{ev.id}</dd>
            <dt>Status</dt><dd>{ev.reviewed ? "Reviewed" : "To review"}</dd>
          </dl>
          <div className="viewer-actions">
            <button type="button" className="btn btn-primary" onClick={onToggleReviewed}>
              <Check className="ico" aria-hidden="true" />{ev.reviewed ? "Mark not reviewed" : "Mark reviewed"}
            </button>
            <a className="btn btn-secondary" href={api.photoUrl(ev, true)} download={`aicam_event_${ev.id}.jpg`}>
              <Download className="ico" aria-hidden="true" />Download photo
            </a>
            <button type="button" className="btn btn-danger-ghost" onClick={onDelete}>
              <Trash2 className="ico" aria-hidden="true" />Delete
            </button>
          </div>
          <p className="muted small">Keys: <kbd>←</kbd> <kbd>→</kbd> move, <kbd>R</kbd> mark reviewed, <kbd>Esc</kbd> close</p>
        </aside>
      </div>
    </dialog>
  );
}
