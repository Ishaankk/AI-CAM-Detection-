// Live page: video (F1), alert banner (F5), stale overlay (F9), latest detection (F2),
// alerts on/off (F6), sensitivity (F7), snapshot (F8), recent events (F3).
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Camera, ChevronRight, CircleAlert, Maximize, Minimize, WifiOff } from "lucide-react";
import { api } from "../api/index.js";
import { useLive, STALE_MS } from "../state/LiveContext.jsx";
import { Switch, useArmState, useSensitivity, IdentityBadge } from "../components/Controls.jsx";
import { useShortcut } from "../lib/hooks.js";
import { ago, clock, pct, who } from "../lib/format.js";

const RECENT_MAX = 6;
const BANNER_MS = 60000;

function useOverlay() {
  const { liveness: L, status } = useLive();
  if (!L.connecting && !L.linkOk) {
    return ["Connection to the camera lost",
      `No update for ${Math.round(L.linkAge / 1000)} s. Reconnecting automatically. The buzzer and lights on the camera still work.`];
  }
  if (L.connecting) return ["Connecting to the camera…", ""];
  if (status && status.online === false) return ["Camera offline", "The camera stopped reporting. Check it has power and is on the same Wi-Fi."];
  if (L.statusAge == null || L.statusAge * 1000 >= STALE_MS || L.frameAge == null || L.frameAge * 1000 >= STALE_MS) {
    const worst = Math.max(L.statusAge ?? 0, L.frameAge ?? 0);
    return [L.frameAge == null ? "Waiting for the first picture" : `No update for ${Math.round(worst)} s`,
      "The camera isn't sending new pictures. If this lasts, restart the camera."];
  }
  return null;
}

function Video({ frameRef }) {
  const { reconnects } = useLive();
  const canvasRef = useRef(null);
  const [src, setSrc] = useState(() => api.streamUrl());

  useEffect(() => { if (!api.mock) setSrc(api.streamUrl()); }, [reconnects]);   // fresh stream after a drop
  useEffect(() => (api.mock && canvasRef.current ? api.attachVideo(canvasRef.current) : undefined), []);

  if (api.mock) return <canvas ref={canvasRef} className="stream" aria-label="Live camera view (mock)" />;
  return (
    <img className="stream" src={src} alt="Live camera view. Detected objects are outlined and labelled."
      onError={() => setTimeout(() => setSrc(api.streamUrl()), 2000)} ref={frameRef} />
  );
}

export default function Live() {
  const { status, latest, liveness, subscribe, now, reconnects } = useLive();
  const overlay = useOverlay();
  const arm = useArmState();
  const sens = useSensitivity();
  const frameRef = useRef(null);
  const [banner, setBanner] = useState(null);
  const [fresh, setFresh] = useState(false);
  const [recent, setRecent] = useState([]);
  const [snapMsg, setSnapMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [isFull, setIsFull] = useState(false);

  // recent events, kept live
  const loadRecent = () => api.events({ limit: RECENT_MAX }).then((r) => setRecent(r.items)).catch(() => {});
  useEffect(() => { loadRecent(); }, [reconnects]);
  useEffect(() => subscribe((name, data) => {
    if (name === "detection") {
      setRecent((r) => (r.some((x) => x.id === data.id) ? r : [data, ...r].slice(0, RECENT_MAX)));
      setFresh(true);
    }
    if (name === "alert") setBanner(data);
    if (name === "reviewed") loadRecent();
  }), [subscribe]);
  useEffect(() => { if (!fresh) return undefined; const t = setTimeout(() => setFresh(false), 8000); return () => clearTimeout(t); }, [fresh, latest]);
  useEffect(() => { if (!banner) return undefined; const t = setTimeout(() => setBanner(null), BANNER_MS); return () => clearTimeout(t); }, [banner]);

  const shown = latest || recent[0] || null;

  async function snapshot() {
    setBusy(true);
    try {
      const { blob, name } = await api.snapshot();
      const url = URL.createObjectURL(blob);
      const a = Object.assign(document.createElement("a"), { href: url, download: name });
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      setSnapMsg(`Saved ${name}`);
    } catch (e) {
      setSnapMsg(e.message);
    } finally {
      setBusy(false);
    }
  }
  const frameBox = useRef(null);
  function toggleFull() {
    if (document.fullscreenElement) document.exitFullscreen();
    else frameBox.current?.requestFullscreen?.();
  }
  useEffect(() => {
    const f = () => setIsFull(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", f);
    return () => document.removeEventListener("fullscreenchange", f);
  }, []);
  useShortcut("s", snapshot);
  useShortcut("f", toggleFull);

  return (
    <div className="live-grid">
      <div className="live-main">
        <section className="card video-card" aria-label="Live video">
          <div className="video-frame" ref={frameBox}>
            <Video frameRef={frameRef} />
            {!banner && (
              <div className="video-badges">
                <span className={`live-badge${overlay ? " is-stale" : ""}`}><span className="rec-dot" aria-hidden="true" />LIVE</span>
                <span className="video-chip mono">{!overlay && status?.fps != null ? `${Math.round(status.fps)} fps` : "– fps"}</span>
              </div>
            )}
            {banner && (
              <div className="banner banner-detect" role="alert">
                <span className="banner-icon" aria-hidden="true"><CircleAlert className="ico" /></span>
                <span>{`${who(banner)} detected at ${clock(banner.time)}`}</span>
                <button type="button" className="banner-close" onClick={() => setBanner(null)}>Dismiss</button>
              </div>
            )}
            {overlay && (
              <div className="video-overlay">
                <WifiOff className="ico ico-xl" aria-hidden="true" />
                <p className="overlay-title">{overlay[0]}</p>
                {overlay[1] && <p className="overlay-sub">{overlay[1]}</p>}
              </div>
            )}
          </div>
          <div className="video-tools">
            <button type="button" className="btn btn-secondary" onClick={snapshot} disabled={busy}>
              <Camera className="ico" aria-hidden="true" />Take snapshot<kbd>S</kbd>
            </button>
            <button type="button" className="btn btn-secondary" onClick={toggleFull}>
              {isFull ? <Minimize className="ico" aria-hidden="true" /> : <Maximize className="ico" aria-hidden="true" />}
              {isFull ? "Exit fullscreen" : "Fullscreen"}<kbd>F</kbd>
            </button>
            <span className="tool-msg" role="status">{snapMsg}</span>
          </div>
        </section>

        <section className="card recent-card" aria-labelledby="recent-h">
          <div className="card-head">
            <h2 className="card-label" id="recent-h">Recent</h2>
            <Link className="link-more" to="/events">All events<ChevronRight className="ico" aria-hidden="true" /></Link>
          </div>
          {recent.length ? (
            <ol className="recent-list">
              {recent.map((d) => (
                <li key={d.id}>
                  <Link className="recent-item" to={`/events#event-${d.id}`}>
                    <img src={api.thumbUrl(d)} alt="" width="320" height="180" loading="lazy" />
                    <span className="recent-cap">
                      <b>{!d.reviewed && <i className="dot-new" title="Not reviewed yet" />}{who(d)}</b>
                      <span className="recent-time">{pct(d.confidence)} · {clock(d.time, false)}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ol>
          ) : (
            <p className="muted small">No detections yet. While alerts are on, each one appears here with a photo.</p>
          )}
        </section>
      </div>

      <div className="live-side">
        <section className={`card latest-card${fresh ? " is-fresh" : ""}`} aria-live="polite" aria-labelledby="latest-h">
          <h2 className="card-label" id="latest-h">Latest detection</h2>
          <p className={`latest-object${shown ? "" : " is-empty"}`}>{shown ? who(shown) : "Nothing yet"}</p>
          {shown?.identity && shown.object === "person" && <div className="latest-sub"><IdentityBadge ev={shown} /></div>}
          <div className="meter" aria-hidden="true">
            <div className="meter-fill" style={{ width: `${Math.round((shown?.confidence ?? 0) * 100)}%` }} />
            <div className="meter-mark" style={{ left: `${sens.markPct}%` }} />
          </div>
          <p className="meter-legend"><span>How sure the camera is</span><span><i className="mark-swatch" />Alert line</span></p>
          <p className="latest-meta">
            {shown ? <>{pct(shown.confidence)} sure, at {clock(shown.time)} <span className="ago">({ago(shown.time, now)})</span></> : " "}
          </p>
        </section>

        <section className="card" aria-labelledby="arm-h">
          <div className="arm-row">
            <div>
              <h2 className="card-label" id="arm-h">Alerts</h2>
              <p className={`arm-state${arm.isOn ? " is-on" : ""}`}>{arm.word}</p>
              <p className="muted small">{arm.sub || " "}</p>
            </div>
            <Switch checked={arm.checked} disabled={arm.disabled || !liveness.cameraOnline} labelledBy="arm-h" onChange={arm.toggle} />
          </div>
          <p className={`control-msg${arm.msg.ok ? " is-ok" : ""}`} role="status">{arm.msg.text}</p>
        </section>

        <section className="card" aria-labelledby="sens-h">
          <div className="slider-head">
            <h2 className="card-label" id="sens-h"><label htmlFor="sensitivity">Sensitivity</label></h2>
            <output className="slider-level" htmlFor="sensitivity">{sens.level}</output>
          </div>
          <input id="sensitivity" {...sens.inputProps} />
          <p className="muted small">{sens.help}</p>
        </section>
      </div>
    </div>
  );
}
