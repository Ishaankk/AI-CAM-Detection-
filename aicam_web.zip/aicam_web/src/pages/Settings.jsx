// Settings: alerts, sensitivity, face recognition, theme, sound, password.
import { useEffect, useState } from "react";
import { Lock, Monitor, Moon, Sun } from "lucide-react";
import { api } from "../api/index.js";
import { useAuth } from "../state/AuthContext.jsx";
import { Switch, useArmState, useSensitivity } from "../components/Controls.jsx";
import { applyTheme, prefs } from "../lib/prefs.js";
import { chime } from "../lib/sound.js";

const MIN_PASSWORD = 12;

export default function Settings() {
  const { user } = useAuth();
  const arm = useArmState();
  const sens = useSensitivity();
  const [theme, setTheme] = useState(prefs.get("theme", "light"));
  const [sound, setSound] = useState(prefs.get("sound", "0") === "1");
  const [rec, setRec] = useState(null);
  const [recMsg, setRecMsg] = useState("");
  const [pw, setPw] = useState({ current: "", next: "", again: "" });
  const [pwMsg, setPwMsg] = useState({ text: "", ok: false });
  const [pwBusy, setPwBusy] = useState(false);

  useEffect(() => { api.getSettings().then(setRec).catch((e) => setRecMsg(e.message)); }, []);

  async function saveRec(change) {
    const before = rec;
    setRec({ ...rec, ...change });
    setRecMsg("");
    try { setRec(await api.putSettings(change)); } catch (e) { setRec(before); setRecMsg(e.message); }
  }

  function chooseTheme(t) { setTheme(t); prefs.set("theme", t); applyTheme(t); }
  function toggleSound(on) { setSound(on); prefs.set("sound", on ? "1" : "0"); if (on) chime("detect", true); }

  async function changePassword(e) {
    e.preventDefault();
    if (pw.next !== pw.again) { setPwMsg({ text: "The two new passwords don't match.", ok: false }); return; }
    if (pw.next.length < MIN_PASSWORD) { setPwMsg({ text: `Use at least ${MIN_PASSWORD} characters.`, ok: false }); return; }
    setPwBusy(true);
    try {
      await api.changePassword(pw.current, pw.next);
      setPw({ current: "", next: "", again: "" });
      setPwMsg({ text: "Password changed. Other devices have been signed out.", ok: true });
    } catch (err) {
      setPwMsg({ text: err.message, ok: false });
    } finally { setPwBusy(false); }
  }

  return (
    <div className="settings">
      <section className="card setting-section" aria-labelledby="det-h">
        <h2 id="det-h">Detection</h2>
        <div className="setting-row">
          <div>
            <p className="setting-name" id="set-arm">Alerts</p>
            <p className="muted small"><b>{arm.word}</b>{arm.sub && ` · ${arm.sub}`}</p>
          </div>
          <Switch checked={arm.checked} disabled={arm.disabled} labelledBy="set-arm" onChange={arm.toggle} />
        </div>
        <p className={`control-msg${arm.msg.ok ? " is-ok" : ""}`} role="status">{arm.msg.text}</p>
        <div className="setting-row setting-row-stack">
          <div className="slider-head">
            <label className="setting-name" htmlFor="sensitivity">Sensitivity</label>
            <output className="slider-level" htmlFor="sensitivity">{sens.level}</output>
          </div>
          <input id="sensitivity" {...sens.inputProps} />
          <p className="muted small">{sens.help}</p>
        </div>
      </section>

      <section className="card setting-section" aria-labelledby="face-h">
        <h2 id="face-h">Face recognition</h2>
        <div className="setting-row">
          <div>
            <p className="setting-name" id="set-rec">Recognise people</p>
            <p className="muted small">Names people added on the People page. Runs on the Pi; nothing leaves it.</p>
          </div>
          <Switch checked={!!rec?.recognition} disabled={!rec} labelledBy="set-rec" onChange={(v) => saveRec({ recognition: v })} />
        </div>
        <div className="setting-row">
          <div>
            <p className="setting-name" id="set-known">Alert for known people too</p>
            <p className="muted small">Off: only unknown people and other objects alert you. Known people are still saved to Events.</p>
          </div>
          <Switch checked={!!rec?.alert_known_people} disabled={!rec || !rec.recognition} labelledBy="set-known"
            onChange={(v) => saveRec({ alert_known_people: v })} />
        </div>
        <p className="control-msg" role="status">{recMsg}</p>
      </section>

      <section className="card setting-section" aria-labelledby="look-h">
        <h2 id="look-h">Display and sound</h2>
        <div className="setting-row">
          <div>
            <p className="setting-name" id="theme-h">Theme</p>
            <p className="muted small">Dark is easier on a monitor left on all day.</p>
          </div>
          <div className="segmented" role="group" aria-labelledby="theme-h">
            {[["light", "Light", Sun], ["dark", "Dark", Moon], ["system", "Auto", Monitor]].map(([v, t, Icon]) => (
              <button key={v} type="button" aria-pressed={theme === v} onClick={() => chooseTheme(v)}>
                <Icon className="ico" aria-hidden="true" />{t}
              </button>
            ))}
          </div>
        </div>
        <div className="setting-row">
          <div>
            <p className="setting-name" id="sound-h">Alert sound in this browser</p>
            <p className="muted small">A short chime on detections, a longer one on tamper. Saved for this browser only.</p>
          </div>
          <div className="row-gap">
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => chime("detect", true)}>Test</button>
            <Switch checked={sound} labelledBy="sound-h" onChange={toggleSound} />
          </div>
        </div>
      </section>

      <section className="card setting-section" aria-labelledby="acct-h">
        <h2 id="acct-h">Account</h2>
        <p className="muted small">Signed in as <b>{user}</b>. Sessions end after 12 hours without use.</p>
        <form className="form form-inline" onSubmit={changePassword} autoComplete="off">
          <label className="field"><span>Current password</span>
            <input type="password" autoComplete="current-password" required value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} /></label>
          <label className="field"><span>New password</span>
            <input type="password" autoComplete="new-password" minLength={MIN_PASSWORD} required value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /></label>
          <label className="field"><span>New password again</span>
            <input type="password" autoComplete="new-password" minLength={MIN_PASSWORD} required value={pw.again} onChange={(e) => setPw({ ...pw, again: e.target.value })} /></label>
          <button type="submit" className="btn btn-primary" disabled={pwBusy}><Lock className="ico" aria-hidden="true" />Change password</button>
        </form>
        <p className={`control-msg${pwMsg.ok ? " is-ok" : ""}`} role="status">{pwMsg.text}</p>
      </section>
    </div>
  );
}
