import { useState } from "react";
import { Navigate, useSearchParams } from "react-router-dom";
import { api } from "../api/index.js";
import { useAuth } from "../state/AuthContext.jsx";
import logo from "../logo.svg";

/** Only allow redirects back into this app (blocks //evil.com and https://evil.com). */
function safeNext(next) {
  if (!next || !next.startsWith("/") || next.startsWith("//")) return "/";
  return next;
}

export default function Login() {
  const { state, login, expired } = useAuth();
  const [params] = useSearchParams();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [locked, setLocked] = useState(false);
  const [busy, setBusy] = useState(false);

  if (state === "in") return <Navigate to={safeNext(params.get("next"))} replace />;

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await login(username, password);
    } catch (err) {
      setError(err.message);
      setLocked(err.status === 429);
      setPassword("");
    } finally { setBusy(false); }
  }

  return (
    <div className="login-body">
      <main className="login-card">
        <img className="login-logo" src={logo} alt="" width="48" height="48" />
        <h1>AI Camera</h1>
        <p className="login-sub">Sign in to see the live view and alerts.</p>
        {expired && !error && <p className="form-error" role="alert">You were signed out. Sign in again to continue.</p>}
        {error && <p className="form-error" role="alert">{error}</p>}
        <form className="form" onSubmit={submit}>
          <label className="field"><span>Username</span>
            <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required
              autoCapitalize="none" spellCheck="false" disabled={locked} /></label>
          <label className="field"><span>Password</span>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password"
              required autoFocus disabled={locked} /></label>
          <button className="btn btn-primary btn-block" type="submit" disabled={busy || locked}>{busy ? "Signing in…" : "Sign in"}</button>
        </form>
        <p className="login-foot">
          {api.mock
            ? <>Mock mode: sign in as <code>admin</code> with <code>demo-password</code>.</>
            : <>Forgot the password? Reset it on the camera's computer with the server's set-password command.</>}
        </p>
      </main>
    </div>
  );
}
