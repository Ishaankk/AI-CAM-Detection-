// People page: who the camera should recognise (stage 2 face recognition).
// Only face embeddings are kept on the Pi; photos are deleted after enrolment.
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Camera, ScanFace, Trash2, Upload, UserPlus } from "lucide-react";
import { api } from "../api/index.js";
import { useLive } from "../state/LiveContext.jsx";
import { EmptyState } from "../components/Controls.jsx";
import { day } from "../lib/format.js";

const MAX_PHOTOS = 10;
const MAX_BYTES = 5 * 1024 * 1024;

function PersonCard({ p, onDelete, onCapture }) {
  const thumb = api.personThumbUrl(p);
  const state = p.state === "enrolling" ? ["is-busy", "Learning this face…"]
    : p.state === "failed" ? ["is-failed", p.error || "Enrolment failed. Try clearer photos."]
      : ["", `Ready · ${p.samples} face sample${p.samples === 1 ? "" : "s"}`];
  return (
    <li className="card person">
      <div className="person-top">
        {thumb ? <img className="avatar" src={thumb} alt="" width="64" height="64" /> : <span className="avatar">{p.name[0]}</span>}
        <div>
          <p className="person-name">{p.name}</p>
          <p className={`person-state ${state[0]}`} role="status">{state[1]}</p>
        </div>
      </div>
      <div className="person-foot">
        <span className="muted small" style={{ whiteSpace: "nowrap" }}>Added {day(p.added)}</span>
        <div className="row-gap">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => onCapture(p)} disabled={p.state === "enrolling"}
            title="Stand in front of the camera to add more face samples">
            <Camera className="ico" aria-hidden="true" />Add samples
          </button>
          <button type="button" className="btn btn-danger-ghost btn-sm" onClick={() => onDelete(p)} aria-label={`Delete ${p.name}`}>
            <Trash2 className="ico" aria-hidden="true" />
          </button>
        </div>
      </div>
    </li>
  );
}

export default function People() {
  const { subscribe, status } = useLive();
  const [people, setPeople] = useState(null);
  const [error, setError] = useState("");
  const [name, setName] = useState("");
  const [consent, setConsent] = useState(false);
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [msg, setMsg] = useState({ text: "", ok: false });
  const [busy, setBusy] = useState(false);
  const [over, setOver] = useState(false);
  const inputRef = useRef(null);

  const load = () => api.people().then(setPeople).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);
  useEffect(() => subscribe((ev, data) => {
    if (ev !== "people") return;
    setPeople((list) => (list || []).map((p) => (p.id === data.id ? { ...p, ...data } : p)));
  }), [subscribe]);

  useEffect(() => {
    const urls = files.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
  }, [files]);

  function pickFiles(list) {
    const chosen = [...list].filter((f) => /^image\/(jpeg|png)$/.test(f.type));
    const tooBig = chosen.filter((f) => f.size > MAX_BYTES);
    let text = "";
    if (chosen.length < list.length) text = "Only JPEG and PNG photos can be used. ";
    if (tooBig.length) text += `${tooBig.length} photo${tooBig.length === 1 ? " is" : "s are"} over 5 MB and were left out. `;
    const ok = chosen.filter((f) => f.size <= MAX_BYTES).slice(0, MAX_PHOTOS);
    if (chosen.length > MAX_PHOTOS) text += `Only the first ${MAX_PHOTOS} photos are used.`;
    setFiles(ok);
    setMsg({ text: text.trim(), ok: false });
  }

  const ready = name.trim().length > 0 && consent;

  async function addWithPhotos(e) {
    e.preventDefault();
    if (!ready) return;
    if (files.length < 3) { setMsg({ text: "Add at least 3 photos, ideally 5 to 10, from slightly different angles.", ok: false }); return; }
    setBusy(true);
    try {
      await api.addPerson({ name: name.trim(), consent, files });
      setName(""); setConsent(false); setFiles([]);
      setMsg({ text: "Added. The camera is learning the face; this takes a few seconds.", ok: true });
      load();
    } catch (err) {
      setMsg({ text: err.message, ok: false });
    } finally { setBusy(false); }
  }

  async function addWithCamera() {
    if (!ready) return;
    setBusy(true);
    try {
      await api.addPerson({ name: name.trim(), consent, files: [], source: "camera" });
      setName(""); setConsent(false); setFiles([]);
      setMsg({ text: "Look at the camera for a few seconds while it captures your face.", ok: true });
      load();
    } catch (err) {
      setMsg({ text: err.message, ok: false });
    } finally { setBusy(false); }
  }

  async function capture(p) {
    try {
      await api.capturePerson(p.id, 8);
      setPeople((list) => list.map((x) => (x.id === p.id ? { ...x, state: "enrolling", error: null } : x)));
    } catch (err) { setError(err.message); }
  }

  async function remove(p) {
    if (!window.confirm(`Delete ${p.name}? Their face data is removed and past events no longer show their name.`)) return;
    try {
      await api.deletePerson(p.id);
      setPeople((list) => list.filter((x) => x.id !== p.id));
    } catch (err) { setError(err.message); }
  }

  const recognitionOff = status && status.recognition === false;

  return (
    <>
      {recognitionOff && (
        <p className="note" role="status">
          Face recognition is off, so people are shown as "Person". Turn it on in <Link to="/settings">Settings</Link>.
        </p>
      )}

      <section className="card" aria-labelledby="enrol-h">
        <div className="card-head">
          <h2 className="card-label" id="enrol-h">Add a person</h2>
        </div>
        <form className="enrol" onSubmit={addWithPhotos}>
          <div className="form">
            <label className="field">
              <span>Name</span>
              <input value={name} maxLength={40} onChange={(e) => setName(e.target.value)} placeholder="e.g. Riya" autoComplete="off" />
            </label>
            <label className="check">
              <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
              <span>{name.trim() || "This person"} agreed to be recognised by this camera.</span>
            </label>
            <p className="note">
              The camera keeps only face measurements, not the photos. You can delete a person at any time,
              and their name disappears from past events.
            </p>
            <p className={`control-msg${msg.ok ? " is-ok" : ""}`} role="status">{msg.text}</p>
          </div>

          <div className="form">
            <label className={`drop${over ? " is-over" : ""}`}
              onDragOver={(e) => { e.preventDefault(); setOver(true); }}
              onDragLeave={() => setOver(false)}
              onDrop={(e) => { e.preventDefault(); setOver(false); pickFiles(e.dataTransfer.files); }}>
              <Upload className="ico" aria-hidden="true" />
              <b>Add 5 to 10 photos of their face</b>
              <span className="small">Different angles and lighting. JPEG or PNG, up to 5 MB each.</span>
              <input ref={inputRef} type="file" accept="image/jpeg,image/png" multiple onChange={(e) => pickFiles(e.target.files)} />
            </label>
            {previews.length > 0 && (
              <div className="thumbs" aria-label={`${previews.length} photos chosen`}>
                {previews.map((u) => <img key={u} src={u} alt="" />)}
              </div>
            )}
            <div className="row-gap">
              <button type="submit" className="btn btn-primary" disabled={!ready || busy || files.length === 0}>
                <UserPlus className="ico" aria-hidden="true" />Add with photos
              </button>
              <button type="button" className="btn btn-secondary" disabled={!ready || busy || files.length > 0} onClick={addWithCamera}
                title="The person stands in front of the camera instead of uploading photos">
                <ScanFace className="ico" aria-hidden="true" />Use the camera instead
              </button>
            </div>
          </div>
        </form>
      </section>

      <div className="list-head">
        <p className="muted" role="status">
          {error || (people == null ? "Loading…" : `${people.length} ${people.length === 1 ? "person" : "people"} recognised`)}
        </p>
      </div>
      {people?.length ? (
        <ul className="people-grid">
          {people.map((p) => <PersonCard key={p.id} p={p} onDelete={remove} onCapture={capture} />)}
        </ul>
      ) : people && (
        <EmptyState icon={ScanFace} title="No one added yet">
          Add family members so alerts can tell them apart from strangers.
        </EmptyState>
      )}
    </>
  );
}
