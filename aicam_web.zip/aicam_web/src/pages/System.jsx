// System page: health cards and 30-minute charts.
import { useEffect, useState } from "react";
import { Camera, Clock, Cpu, Eye, Gauge, HardDrive, Server, Thermometer } from "lucide-react";
import { api } from "../api/index.js";
import { useLive } from "../state/LiveContext.jsx";
import { LineChart } from "../components/Charts.jsx";
import { duration } from "../lib/format.js";

const TEMP_LIMIT = 80;   // the Pi 5 starts slowing itself down around 80-85 °C

function Stat({ icon: Icon, label, value, sub, state, mono = true }) {
  return (
    <section className="card stat" data-state={state || undefined}>
      <p className="stat-label"><Icon className="ico" aria-hidden="true" />{label}</p>
      <p className={`stat-value${mono ? " mono" : ""}`}>{value}</p>
      <p className="stat-sub muted">{sub || " "}</p>
    </section>
  );
}

export default function System() {
  const { status: s, health: hl, liveness: L, subscribe } = useLive();
  const [info, setInfo] = useState(null);
  const [rows, setRows] = useState([]);
  const [loadedAt, setLoadedAt] = useState(Date.now());

  useEffect(() => {
    api.system().then((d) => { setInfo(d); setRows(d.history || []); setLoadedAt(Date.now()); }).catch(() => {});
  }, []);
  useEffect(() => subscribe((name, d) => {
    if (name === "status" && d.online) {
      setRows((r) => [...r.filter((x) => x.t >= Date.now() / 1000 - 1800), { t: Date.now() / 1000, temp_c: d.temp_c, fps: d.fps }]);
    }
  }), [subscribe]);

  const broker = hl?.broker || info?.health?.broker;
  const temps = rows.map((r) => r.temp_c).filter((v) => v != null);
  const fpss = rows.map((r) => r.fps).filter((v) => v != null);
  const range = (v, u, d = 1) => (v.length ? `${Math.min(...v).toFixed(d)}–${Math.max(...v).toFixed(d)} ${u}` : "");

  return (
    <>
      <div className="stat-grid">
        <Stat icon={Camera} label="Camera" mono={false}
          value={L.cameraOnline ? "Online" : L.connecting ? "Checking" : "Offline"}
          sub={L.statusAge != null ? `Last report ${Math.round(L.statusAge)} s ago` : "No report yet"}
          state={L.cameraOnline ? "ok" : L.connecting ? "" : "bad"} />
        <Stat icon={Thermometer} label="Pi temperature" value={s?.temp_c == null ? "–" : `${s.temp_c.toFixed(1)} °C`}
          sub={s?.temp_c == null ? "Not reported" : s.temp_c >= 75 ? "Hot: check the cooler" : "Normal"} state={s?.temp_c >= 75 ? "warn" : ""} />
        <Stat icon={Gauge} label="Frame rate" value={s?.fps == null || !L.cameraOnline ? "–" : s.fps.toFixed(1)} sub="frames per second" />
        <Stat icon={HardDrive} label="Free storage" value={s?.free_gb == null ? "–" : `${s.free_gb.toFixed(1)} GB`}
          sub={s?.low_space ? "Below 1 GB: photos paused" : info?.snapshots != null ? `${info.snapshots} photos stored` : ""} state={s?.low_space ? "bad" : ""} />
        <Stat icon={Cpu} label="Pi load (1 min)" value={s?.load_1m == null ? "–" : s.load_1m.toFixed(2)}
          sub="4 cores = 4.00 is fully busy" state={s?.load_1m >= 3.5 ? "warn" : ""} />
        <Stat icon={Clock} label="Pi running for" value={duration(s?.uptime_s)}
          sub={info ? `Web server: ${duration(info.server_uptime_s + (Date.now() - loadedAt) / 1000)}` : ""} />
        <Stat icon={Server} label="Message broker" mono={false}
          value={broker === "connected" ? "Connected" : broker ? "Not connected" : "–"} sub="Mosquitto on the Pi"
          state={broker === "connected" ? "ok" : broker ? "bad" : ""} />
        <Stat icon={Eye} label="Open viewers" value={hl?.viewers != null ? String(hl.viewers) : "–"} sub="Target: up to 3 at once"
          state={hl?.viewers > 3 ? "warn" : ""} />
      </div>

      <div className="chart-grid">
        <section className="card" aria-labelledby="ch-temp-h">
          <div className="card-head">
            <h2 className="card-label" id="ch-temp-h">Temperature, last 30 min</h2>
            <span className="muted small mono">{range(temps, "°C")}</span>
          </div>
          <LineChart rows={rows} field="temp_c" unit=" °C" limit={TEMP_LIMIT} limitText={`${TEMP_LIMIT} °C slows down`} label="Pi temperature over the last 30 minutes" />
        </section>
        <section className="card" aria-labelledby="ch-fps-h">
          <div className="card-head">
            <h2 className="card-label" id="ch-fps-h">Frame rate, last 30 min</h2>
            <span className="muted small mono">{range(fpss, "fps")}</span>
          </div>
          <LineChart rows={rows} field="fps" unit=" fps" label="Camera frame rate over the last 30 minutes" />
        </section>
      </div>

      <section className="card" aria-labelledby="store-h">
        <h2 className="card-label" id="store-h">Storage rules</h2>
        <dl className="facts-row">
          <div><dt>Keep newest</dt><dd>{info?.retention?.keep ?? 500} photos</dd></div>
          <div><dt>Delete after</dt><dd>{info?.retention?.days ?? 14} days</dd></div>
          <div><dt>Stop saving below</dt><dd>{info?.retention?.min_free_gb ?? 1} GB free</dd></div>
          <div><dt>Connection</dt><dd>{info?.https ? "HTTPS (encrypted)" : "HTTP (local Wi-Fi only)"}</dd></div>
          <div><dt>Version</dt><dd className="mono">{info?.version || "–"}</dd></div>
        </dl>
      </section>
    </>
  );
}
