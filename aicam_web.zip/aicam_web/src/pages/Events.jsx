// Events page: every saved detection, 24 h activity, filters (object, who, review status, dates),
// photo viewer, review workflow and bulk actions.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import { Check, CheckCheck, Images, RefreshCw, Trash2 } from "lucide-react";
import { api } from "../api/index.js";
import { useLive } from "../state/LiveContext.jsx";
import { ActivityChart, bucketByHour } from "../components/Charts.jsx";
import { EventViewer } from "../components/EventViewer.jsx";
import { EmptyState, IdentityBadge } from "../components/Controls.jsx";
import { useShortcut } from "../lib/hooks.js";
import { clock, day, label, pct, who } from "../lib/format.js";

const PAGE_SIZE = 48;
const FILTER_KEYS = ["object", "who", "reviewed", "from", "to"];

export default function Events() {
  const { summary, refreshSummary, subscribe, reconnects } = useLive();
  const [params, setParams] = useSearchParams();
  const location = useLocation();
  const startHash = useRef(location.hash);
  const filters = useMemo(() => Object.fromEntries(FILTER_KEYS.map((k) => [k, params.get(k) || (["object", "who", "reviewed"].includes(k) ? "all" : "")])), [params]);
  const active = FILTER_KEYS.some((k) => filters[k] && filters[k] !== "all");

  const [items, setItems] = useState([]);
  const [next, setNext] = useState(null);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [people, setPeople] = useState([]);
  const [newCount, setNewCount] = useState(0);
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState(() => new Set());
  const [viewIdx, setViewIdx] = useState(-1);

  const setFilter = (key, value) => {
    const p = new URLSearchParams(params);
    if (!value || value === "all") p.delete(key); else p.set(key, value);
    setParams(p, { replace: true });
  };

  const load = useCallback(async (reset) => {
    setLoading(true);
    setError("");
    try {
      const res = await api.events({ ...filters, limit: PAGE_SIZE, before: reset ? "" : next || "" });
      setItems((cur) => (reset ? res.items : [...cur, ...res.items]));
      setNext(res.next);
      setTotal(res.total);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
    return null;
  }, [filters, next]);

  // reload when filters change or the connection comes back
  useEffect(() => { setNewCount(0); load(true); refreshSummary(); }, [filters, reconnects]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { api.people().then(setPeople).catch(() => {}); }, []);

  // opened from the Live page's Recent list (#event-42)
  useEffect(() => {
    const m = /^#event-(\d+)$/.exec(startHash.current || "");
    if (!m || loading) return;
    const i = items.findIndex((d) => d.id === Number(m[1]));
    if (i >= 0) setViewIdx(i);
    startHash.current = "";
  }, [items, loading]);

  // live: new detections slide in when no filter is set; otherwise offer a refresh
  useEffect(() => subscribe((name, data) => {
    if (name !== "detection") return;
    if (!active) {
      setItems((cur) => (cur.some((x) => x.id === data.id) ? cur : [{ ...data, isNew: true }, ...cur]));
      setTotal((t) => t + 1);
    } else {
      setNewCount((n) => n + 1);
    }
  }), [subscribe, active]);

  const { counts, start } = useMemo(() => bucketByHour(summary?.recent_ts), [summary]);
  const sum = counts.reduce((a, b) => a + b, 0);
  const peak = counts.indexOf(Math.max(...counts));
  const objects = summary?.objects || {};
  const allCount = Object.values(objects).reduce((a, b) => a + b, 0);

  // ---- review / delete ----
  const markReviewed = async (ids, reviewed = true) => {
    await api.review({ ids, reviewed });
    setItems((cur) => cur.map((d) => (ids.includes(d.id) ? { ...d, reviewed } : d)));
  };
  const reviewAll = async () => {
    try {
      await api.review({ all: true, reviewed: true });
      setItems((cur) => cur.map((d) => ({ ...d, reviewed: true })));
    } catch (e) { setError(e.message); }
  };
  const remove = async (ids) => {
    await api.deleteEvents(ids);
    setItems((cur) => cur.filter((d) => !ids.includes(d.id)));
    setTotal((t) => t - ids.length);
  };

  const stopSelecting = () => { setSelecting(false); setSelected(new Set()); };
  const toggle = (id) => setSelected((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  useShortcut("escape", stopSelecting, selecting);

  const viewing = viewIdx >= 0 ? items[viewIdx] : null;

  const whoChips = [
    ["all", "Anyone"], ["unknown", "Unknown people"], ["known", "Known people"],
    ...people.map((p) => [String(p.id), p.name]),
  ];

  return (
    <>
      <section className="card" aria-labelledby="act-h">
        <div className="card-head">
          <div>
            <h2 className="card-label" id="act-h">Last 24 hours</h2>
            <p className="stat-big"><span className="mono">{summary ? sum : "–"}</span> <span className="muted">detections</span></p>
          </div>
          {sum > 0 && (
            <p className="muted small">Busiest hour: {new Date((start + peak * 3600) * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })} ({counts[peak]})</p>
          )}
        </div>
        <ActivityChart counts={counts} start={start} />
      </section>

      <section className="card toolbar" aria-label="Filters">
        <div className="chips" role="group" aria-label="Object">
          <button type="button" className="chip" aria-pressed={filters.object === "all"} onClick={() => setFilter("object", "all")}>
            All objects <span className="chip-count">{allCount}</span>
          </button>
          {Object.entries(objects).map(([o, n]) => (
            <button key={o} type="button" className="chip" aria-pressed={filters.object === o} onClick={() => setFilter("object", o)}>
              {label(o)} <span className="chip-count">{n}</span>
            </button>
          ))}
        </div>
        <div className="toolbar-group">
          <div className="segmented" role="group" aria-label="Review status">
            {[["all", "All"], ["0", "To review"], ["1", "Reviewed"]].map(([v, t]) => (
              <button key={v} type="button" aria-pressed={filters.reviewed === v} onClick={() => setFilter("reviewed", v)}>{t}</button>
            ))}
          </div>
          <label className="date-field"><span>From</span><input type="date" value={filters.from} onChange={(e) => setFilter("from", e.target.value)} /></label>
          <label className="date-field"><span>To</span><input type="date" value={filters.to} onChange={(e) => setFilter("to", e.target.value)} /></label>
          {active && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setParams({}, { replace: true })}>Clear filters</button>}
        </div>
        <div className="chips" role="group" aria-label="Who">
          {whoChips.map(([v, t]) => (
            <button key={v} type="button" className="chip" aria-pressed={filters.who === v} onClick={() => setFilter("who", v)}>{t}</button>
          ))}
        </div>
      </section>

      <div className="list-head">
        <p className="muted" role="status">
          {error || (loading && !items.length ? "Loading…" : `${total} event${total === 1 ? "" : "s"}${active ? " match" : ""}`)}
        </p>
        <div className="list-actions">
          {newCount > 0 && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setNewCount(0); load(true); }}>
              <RefreshCw className="ico" aria-hidden="true" />{newCount} new
            </button>
          )}
          <button type="button" className="btn btn-secondary btn-sm" onClick={() => (selecting ? stopSelecting() : setSelecting(true))}>
            {selecting ? "Done" : "Select"}
          </button>
          <button type="button" className="btn btn-secondary btn-sm" onClick={reviewAll}>
            <CheckCheck className="ico" aria-hidden="true" />Mark all reviewed
          </button>
        </div>
      </div>

      {selecting && (
        <div className="card bulkbar">
          <span>{selected.size} selected</span>
          <div className="spacer" />
          <button type="button" className="btn btn-secondary btn-sm" disabled={!selected.size}
            onClick={async () => { await markReviewed([...selected]); stopSelecting(); }}>
            <Check className="ico" aria-hidden="true" />Mark reviewed
          </button>
          <button type="button" className="btn btn-danger btn-sm" disabled={!selected.size}
            onClick={async () => {
              if (!window.confirm(`Delete ${selected.size} event${selected.size === 1 ? "" : "s"} and their photos? This can't be undone.`)) return;
              await remove([...selected]); stopSelecting();
            }}>
            <Trash2 className="ico" aria-hidden="true" />Delete
          </button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={stopSelecting}>Cancel</button>
        </div>
      )}

      {items.length > 0 ? (
        <ul className={`event-grid${selecting ? " selecting" : ""}`}>
          {items.map((d, i) => (
            <li key={d.id}>
              <button type="button" id={`event-${d.id}`}
                className={`event-card${selected.has(d.id) ? " is-selected" : ""}`}
                aria-label={`${who(d)}, ${pct(d.confidence)} sure, ${day(d.time)} ${clock(d.time, false)}`}
                aria-pressed={selecting ? selected.has(d.id) : undefined}
                onClick={() => (selecting ? toggle(d.id) : setViewIdx(i))}>
                <img src={api.thumbUrl(d)} alt="" width="320" height="180" loading="lazy" />
                {!d.reviewed && <span className="event-flag">{d.isNew ? "New" : "To review"}</span>}
                <span className="event-check" aria-hidden="true"><Check className="ico" /></span>
                <span className="event-cap"><b>{who(d)}</b><span className="pct">{pct(d.confidence)}</span></span>
                <span className="event-when">{day(d.time)} · {clock(d.time)}</span>
                {d.identity && d.object === "person" && <span className="event-when"><IdentityBadge ev={d} /></span>}
              </button>
            </li>
          ))}
        </ul>
      ) : (!loading && (
        <EmptyState icon={Images} title="No events match">Try another object, person or date, or clear the filters.</EmptyState>
      ))}

      {next && <div className="load-more"><button type="button" className="btn btn-secondary" disabled={loading} onClick={() => load(false)}>Load more</button></div>}

      <EventViewer
        ev={viewing}
        hasPrev={viewIdx > 0}
        hasNext={viewIdx >= 0 && (viewIdx < items.length - 1 || !!next)}
        onPrev={() => setViewIdx((i) => Math.max(0, i - 1))}
        onNext={async () => {
          if (viewIdx === items.length - 1 && next) await load(false);
          setViewIdx((i) => i + 1);
        }}
        onClose={() => setViewIdx(-1)}
        onToggleReviewed={() => viewing && markReviewed([viewing.id], !viewing.reviewed).catch((e) => setError(e.message))}
        onDelete={async () => {
          if (!viewing || !window.confirm("Delete this event and its photo? This can't be undone.")) return;
          await remove([viewing.id]);
          setViewIdx((i) => (items.length > 1 ? Math.min(i, items.length - 2) : -1));
        }}
      />
    </>
  );
}
