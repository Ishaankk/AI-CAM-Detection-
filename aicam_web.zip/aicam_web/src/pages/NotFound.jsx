import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <section className="card empty-state">
      <h2>There's no page here.</h2>
      <p className="muted">The link may be old. Use the menu, or go back to the live view.</p>
      <Link className="btn btn-primary" to="/">Go to Live</Link>
    </section>
  );
}
