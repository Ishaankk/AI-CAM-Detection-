import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { api } from "../api/index.js";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState({ state: "loading", user: null, version: "" });

  useEffect(() => {
    api.session()
      .then((s) => setAuth({ state: "in", user: s.user, version: s.version }))
      .catch(() => setAuth({ state: "out", user: null, version: "" }));
    const expired = () => setAuth((a) => (a.state === "in" ? { state: "out", user: null, version: "", expired: true } : a));
    window.addEventListener("aicam:signed-out", expired);
    return () => window.removeEventListener("aicam:signed-out", expired);
  }, []);

  const login = useCallback(async (username, password) => {
    const s = await api.login(username, password);
    setAuth({ state: "in", user: s.user, version: s.version });
  }, []);

  const logout = useCallback(async () => {
    try { await api.logout(); } finally { setAuth({ state: "out", user: null, version: "" }); }
  }, []);

  return <AuthContext.Provider value={{ ...auth, login, logout }}>{children}</AuthContext.Provider>;
}

/** Wrap pages that need sign-in. Sends signed-out visitors to /login and back afterwards. */
export function RequireAuth({ children }) {
  const { state } = useAuth();
  const loc = useLocation();
  if (state === "loading") return <div className="boot" aria-busy="true" />;
  if (state !== "in") return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  return children;
}
