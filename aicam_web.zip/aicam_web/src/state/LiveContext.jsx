// LiveContext - the one live connection every page shares.
// Handles: Server-Sent Events, the 5 s stale warning (F9), reconnect after a Wi-Fi drop (F10),
// alerts and tamper warnings on every page (F5), the unreviewed badge, and arm/sensitivity
// changes that only count once the camera confirms them (F6, F7).
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import { api } from "../api/index.js";
import { chime } from "../lib/sound.js";
import { clock, pct, who } from "../lib/format.js";

export const STALE_MS = 5000;          // F9
const DEAD_LINK_MS = 6000;             // F10: silent this long = dead link, reconnect
const MAX_BACKOFF_MS = 8000;           // keeps worst-case recovery under 10 s
const CONFIRM_MS = 6000;               // wait this long for the camera to confirm a change
const BASE_TITLE = "AI Camera";

const LiveContext = createContext(null);
export const useLive = () => useContext(LiveContext);

export function LiveProvider({ children }) {
  const location = useLocation();
  const onLivePage = location.pathname === "/";

  const [status, setStatus] = useState(null);
  const [health, setHealth] = useState(null);
  const [latest, setLatest] = useState(null);
  const [summary, setSummary] = useState(null);
  const [toasts, setToasts] = useState([]);
  const [pending, setPending] = useState({ arm: null, threshold: null });
  const [controlMsg, setControlMsg] = useState({ text: "", ok: false });
  const [reconnects, setReconnects] = useState(0);
  const [now, setNow] = useState(Date.now());

  const lastMsgAt = useRef(0);
  const connectAt = useRef(0);
  const linkDown = useRef(false);
  const closeRef = useRef(null);
  const backoff = useRef(1000);
  const retryTimer = useRef(null);
  const listeners = useRef(new Set());
  const onLivePageRef = useRef(onLivePage);
  onLivePageRef.current = onLivePage;
  const pendingRef = useRef(pending);
  pendingRef.current = pending;

  // ---------- toasts ----------
  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const toast = useCallback((t) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((list) => [...list.slice(-3), { ...t, id }]);
    if (!t.sticky) setTimeout(() => dismiss(id), t.timeout ?? 6000);
    return id;
  }, [dismiss]);

  // ---------- subscribe for pages (detection, reviewed, people ...) ----------
  const subscribe = useCallback((fn) => {
    listeners.current.add(fn);
    return () => listeners.current.delete(fn);
  }, []);

  const refreshSummary = useCallback(async () => {
    try { setSummary(await api.summary()); } catch { /* shown elsewhere */ }
  }, []);

  // ---------- incoming messages ----------
  const handle = useCallback((name, data) => {
    lastMsgAt.current = Date.now();
    switch (name) {
      case "hello":
        setStatus(data.status);
        setHealth(data.health);
        if (data.latest) setLatest(data.latest);
        break;
      case "status":
        setStatus(data);
        setPending((p) => {
          const next = { ...p };
          if (p.arm && data.armed === p.arm.want) {
            next.arm = null;
            setControlMsg({ text: data.armed ? "Alerts are on." : "Alerts are off.", ok: true });
          }
          if (p.threshold && typeof data.threshold === "number" && Math.abs(data.threshold - p.threshold.value) < 0.01) next.threshold = null;
          return next;
        });
        break;
      case "health":
        setHealth(data);
        break;
      case "detection":
        setLatest(data);
        setSummary((s) => (s ? { ...s, unreviewed: s.unreviewed + 1 } : s));
        break;
      case "alert": {
        chime("detect");
        const title = `${who({ object: data.object, identity: data.identity })} detected`;
        document.title = `(!) ${title} · ${BASE_TITLE}`;
        if (!onLivePageRef.current) {
          toast({ kind: "detect", title, sub: `At ${clock(data.time)}`, href: "/", linkText: "Open live view", timeout: 12000 });
        }
        break;
      }
      case "tamper":
        chime("tamper");
        document.title = `(!) Camera moved · ${BASE_TITLE}`;
        toast({ kind: "tamper", title: "Camera was moved or bumped", sub: `At ${clock(data.time)}. Check it still points the right way.`, sticky: true });
        break;
      case "reviewed":
        refreshSummary();
        break;
      default:
        break;
    }
    listeners.current.forEach((fn) => fn(name, data));
  }, [toast, refreshSummary]);

  // ---------- connection + reconnect ----------
  const connect = useCallback(() => {
    clearTimeout(retryTimer.current);
    retryTimer.current = null;
    closeRef.current?.();
    connectAt.current = Date.now();
    closeRef.current = api.live({
      open: () => {
        backoff.current = 1000;
        if (linkDown.current) {
          linkDown.current = false;
          setReconnects((n) => n + 1);       // pages reload their video and lists
          refreshSummary();
        }
      },
      error: (closed) => {
        linkDown.current = true;
        if (closed) scheduleReconnect();       // eslint-disable-line no-use-before-define
      },
      message: handle,
    });
  }, [handle, refreshSummary]);

  const scheduleReconnect = useCallback(() => {
    if (retryTimer.current) return;
    retryTimer.current = setTimeout(async () => {
      retryTimer.current = null;
      try { await api.session(); } catch (e) { if (e.status === 401) window.dispatchEvent(new Event("aicam:signed-out")); }
      connect();
    }, backoff.current);
    backoff.current = Math.min(backoff.current * 2, MAX_BACKOFF_MS);
  }, [connect]);

  useEffect(() => {
    connect();
    refreshSummary();
    const onOnline = () => { linkDown.current = true; connect(); };
    window.addEventListener("online", onOnline);
    return () => {
      window.removeEventListener("online", onOnline);
      closeRef.current?.();
      clearTimeout(retryTimer.current);
    };
  }, [connect, refreshSummary]);

  // ---------- heartbeat: dead-link check, control timeouts, clock ----------
  useEffect(() => {
    const t = setInterval(() => {
      const n = Date.now();
      setNow(n);
      if (n - Math.max(lastMsgAt.current, connectAt.current) > DEAD_LINK_MS && !retryTimer.current) {
        linkDown.current = true;
        connect();
      }
      const p = pendingRef.current;
      if (p.arm && n > p.arm.until) {
        setPending((x) => ({ ...x, arm: null }));
        setControlMsg({ text: "The camera didn't confirm the change. Check it's online, then try again.", ok: false });
      }
      if (p.threshold && n > p.threshold.until) {
        setPending((x) => ({ ...x, threshold: null }));
        setControlMsg({ text: "The camera didn't confirm the new sensitivity. Try again.", ok: false });
      }
    }, 500);
    return () => clearInterval(t);
  }, [connect]);

  // put the title back once alerts are dismissed
  useEffect(() => {
    if (!toasts.some((t) => t.kind !== "info")) document.title = BASE_TITLE;
  }, [toasts]);

  // ---------- liveness, used by the status bar and the video overlay ----------
  const liveness = useMemo(() => {
    const linkAge = lastMsgAt.current ? now - lastMsgAt.current : Infinity;
    const linkOk = linkAge < STALE_MS;
    const statusAge = health?.status_age;
    const frameAge = health?.frame_age;
    const cameraOnline = linkOk && status?.online === true && statusAge != null && statusAge * 1000 < STALE_MS;
    return { connecting: !lastMsgAt.current, linkOk, linkAge, statusAge, frameAge, cameraOnline };
  }, [now, status, health]);

  // ---------- controls ----------
  const setArmed = useCallback(async (want) => {
    if (pendingRef.current.arm) return;
    setControlMsg({ text: "", ok: false });
    setPending((p) => ({ ...p, arm: { want, until: Date.now() + CONFIRM_MS } }));
    try { await api.setArmed(want); } catch (e) {
      setPending((p) => ({ ...p, arm: null }));
      setControlMsg({ text: e.message, ok: false });
    }
  }, []);

  const setThreshold = useCallback(async (value) => {
    setPending((p) => ({ ...p, threshold: { value, until: Date.now() + CONFIRM_MS } }));
    try { await api.setThreshold(value); } catch (e) {
      setPending((p) => ({ ...p, threshold: null }));
      setControlMsg({ text: e.message, ok: false });
    }
  }, []);

  const value = {
    status, health, latest, setLatest, summary, refreshSummary, liveness, now, reconnects,
    toasts, toast, dismiss, subscribe, pending, controlMsg, setArmed, setThreshold,
    alertText: (d) => `${who(d)} detected at ${clock(d.time)}`, pct,
  };
  return <LiveContext.Provider value={value}>{children}</LiveContext.Provider>;
}
