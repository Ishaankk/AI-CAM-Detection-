import { Route, Routes } from "react-router-dom";
import { AuthProvider, RequireAuth } from "./state/AuthContext.jsx";
import { LiveProvider } from "./state/LiveContext.jsx";
import { Layout } from "./components/Layout.jsx";
import Live from "./pages/Live.jsx";
import Events from "./pages/Events.jsx";
import People from "./pages/People.jsx";
import System from "./pages/System.jsx";
import Settings from "./pages/Settings.jsx";
import Login from "./pages/Login.jsx";
import NotFound from "./pages/NotFound.jsx";

/** Adding a page: a route here + one entry in NAV (components/Layout.jsx). */
export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<RequireAuth><LiveProvider><Layout /></LiveProvider></RequireAuth>}>
          <Route index element={<Live />} />
          <Route path="events" element={<Events />} />
          <Route path="people" element={<People />} />
          <Route path="system" element={<System />} />
          <Route path="settings" element={<Settings />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </AuthProvider>
  );
}
