# Backend

The backend is specified in **AI Camera Backend Specification** (shared doc):
https://claude.ai/code/artifact/0e2c63c7-a6f1-4a8b-8fde-e5f8bffde2dd

Summary of what this frontend expects from it:

- Go API server on the Pi, port 8000, serving the built `dist/` folder and these routes:
  `/api/auth/{login,logout,session}`, `/api/account/password`, `/api/live` (Server-Sent Events),
  `/api/stream` (MJPEG), `/api/status`, `/api/control/{arm,threshold}`, `/api/settings`,
  `/api/snapshot`, `/api/events`, `/api/events/{summary,review,delete}`, `/api/system`,
  `/api/people`, `/api/people/{id}/capture`, `DELETE /api/people/{id}`,
  `/media/{snapshots,thumbs}/{uid}.jpg`, `/media/people/{id}.jpg`, `/healthz`.
- Session cookie + `X-CSRF-Token` header on every non-GET request (token comes from login/session).
- Errors as `{"error": "plain-English message"}`.
- Unknown paths that aren't `/api` or `/media` must return `index.html` so React's routes work
  after a page refresh (e.g. `/events`).

`src/api/client.js` is the exact list of calls; `src/api/mock.js` is a working example of every response.
